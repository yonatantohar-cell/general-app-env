# סימולציה 9 — בינוני

סימולציה בשישה פרקי הליבה של האמירנט ברמה בינונית, המשלבת אוצר מילים אקדמי ומבני משפט מורכבים יותר.

**רמה:** בינוני  
**שאלות במאגר:** 29  
**מוגשות בסימולציה:** 23  
**זמן:** 39 דקות  
**מקור:** https://amirnetwords.com/tests/test-09/play

> הסימולציה מגישה 23 שאלות מתוך מאגר של 29, ובוחרת אותן באופן מסתגל. כאן מופיע המאגר המלא.

---

## פרק 1 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 1.

A passport is needed to \_\_\_\_ another country.

**A.** empty  
**B.** erase  
**C.** earn  
**D.** enter

#### 2.

She speaks softly \_\_\_\_ the baby is sleeping.

**A.** so  
**B.** but  
**C.** because  
**D.** although

#### 3.

The teacher will \_\_\_\_ the students based on their progress.

**A.** assess  
**B.** assist  
**C.** assume  
**D.** assign

#### 4.

The results were \_\_\_\_ with our original hypothesis.

**A.** contrary  
**B.** consistent  
**C.** curious  
**D.** careful

#### 5.

You should save the document \_\_\_\_ you lose your work.

**A.** so that  
**B.** as if  
**C.** in case  
**D.** even though

#### 6.

The negotiations broke down because neither side was willing to \_\_\_\_.

**A.** comprehend  
**B.** compliment  
**C.** compose  
**D.** compromise

## פרק 2 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 7.

The coffee was cold, \_\_\_\_ I drank it quickly.

**A.** so  
**B.** but  
**C.** because  
**D.** although

#### 8.

The students raised their hands to \_\_\_\_ questions.

**A.** add  
**B.** aim  
**C.** ask  
**D.** age

#### 9.

The instructions were so \_\_\_\_ that nobody understood them.

**A.** confusing  
**B.** convincing  
**C.** comforting  
**D.** charming

#### 10.

The bridge collapsed \_\_\_\_ the strong winds.

**A.** in case of  
**B.** instead of  
**C.** due to  
**D.** apart from

#### 11.

Although the data appeared promising, the conclusions were drawn \_\_\_\_.

**A.** prematurely  
**B.** precisely  
**C.** patiently  
**D.** persistently

#### 12.

The historian was careful to \_\_\_\_ fact from speculation throughout the book.

**A.** diminish  
**B.** distribute  
**C.** distinguish  
**D.** dissolve

## פרק 3 — הבנת הנקרא

*5 שאלות בסימולציה · 5 במאגר · 15 דקות*

קראו את הקטע האקדמי הקצר ולאחר מכן ענו על השאלות הנוגעות אליו. כל התשובות מתבססות על המידע שבטקסט בלבד.

### קטע הקריאה: Why Coral Reefs Matter

> Coral reefs cover only a tiny fraction of the ocean floor, yet they support an enormous share of all sea life. These reefs are built by small animals called corals, which slowly create hard structures over many years. The complex shapes of a reef provide shelter and food for countless fish and other creatures. In this way, a healthy reef acts like an underwater city, full of activity. Reefs also protect coastlines by breaking the force of large waves before they reach the shore. However, coral reefs are very sensitive to changes in their environment. When the water becomes too warm, corals can lose their color and, if the heat continues, may die. Pollution and overfishing add further pressure. Because so many species and communities depend on them, protecting coral reefs has become an important goal for scientists and governments alike.

#### 13.

What is the passage mainly about?

**A.** How fish learn to swim in groups.  
**B.** Why coral reefs are important and why they are at risk.  
**C.** Why the ocean floor is mostly empty.  
**D.** How to build a city underwater.

#### 14.

Who builds coral reefs?

**A.** Large fish that live near the shore.  
**B.** Small animals called corals.  
**C.** Scientists studying the ocean.  
**D.** Waves moving across the sea.

#### 15.

According to the passage, how do reefs protect coastlines?

**A.** They make the water warmer near the shore.  
**B.** They block all fish from the coast.  
**C.** They raise the level of the sea.  
**D.** They break the force of large waves before they reach the shore.

#### 16.

What can happen to corals when the water becomes too warm?

**A.** They grow much faster than usual.  
**B.** They turn into fish over time.  
**C.** They can lose their color and may die if the heat continues.  
**D.** They become stronger and more colorful.

#### 17.

Which extra pressures on reefs does the passage mention?

**A.** Pollution and overfishing.  
**B.** Bright sunlight and gentle waves.  
**C.** Cold water and clean air.  
**D.** Heavy rain and strong winds.

## פרק 4 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 18.

The store offers a refund only if the product is faulty.

**A.** The store gives a refund for any product, working or not.  
**B.** You can get your money back from the store just when the product is defective.  
**C.** The store never gives refunds, even for faulty products.  
**D.** The store offers a refund only if the product works well.

#### 19.

Many experts believe the economy will recover slowly.

**A.** Most experts believe the economy will collapse quickly.  
**B.** Experts agree the economy has already fully recovered.  
**C.** A lot of experts think the economy will improve at a gradual pace.  
**D.** Few experts expect the economy to recover at all.

#### 20.

The teacher allowed the students to use a dictionary during the test.

**A.** During the test, the students were permitted to use a dictionary.  
**B.** The teacher forbade the students from using a dictionary in the test.  
**C.** The students used a dictionary only after the test.  
**D.** The teacher used the dictionary instead of the students.

## פרק 5 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 21.

The longer he waited, the more nervous he became.

**A.** His nervousness grew as the waiting continued.  
**B.** He became calmer the longer he waited.  
**C.** He waited a short time and felt very nervous.  
**D.** The waiting had no effect on how he felt.

#### 22.

The festival attracts thousands of tourists each summer.

**A.** The festival keeps tourists away every summer.  
**B.** Every summer, the festival draws thousands of tourists.  
**C.** Only a few tourists come to the festival each summer.  
**D.** The festival takes place in winter, not summer.

#### 23.

He could not attend the meeting due to a prior commitment.

**A.** He attended the meeting despite a prior commitment.  
**B.** He cancelled all his commitments to attend the meeting.  
**C.** A previous arrangement prevented him from coming to the meeting.  
**D.** He missed the meeting because he forgot about it.

## פרק 6 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 24.

Doctors advise people to \_\_\_\_ regularly for good health.

**A.** expire  
**B.** export  
**C.** exercise  
**D.** excuse

#### 25.

It was getting dark, \_\_\_\_ we turned on the lights.

**A.** but  
**B.** because  
**C.** although  
**D.** so

#### 26.

The volunteers worked hard \_\_\_\_ improve their community.

**A.** in spite of  
**B.** in order to  
**C.** as a result  
**D.** on the whole

#### 27.

The scientist made a \_\_\_\_ discovery that changed the field.

**A.** removable  
**B.** reasonable  
**C.** returnable  
**D.** remarkable

#### 28.

The witness’s testimony was \_\_\_\_, casting doubt on the entire case.

**A.** inconsistent  
**B.** impeccable  
**C.** irrefutable  
**D.** indisputable

#### 29.

The proposal was \_\_\_\_ approved, with only minor reservations expressed.

**A.** reluctantly  
**B.** unanimously  
**C.** narrowly  
**D.** partially

---

## מפתח תשובות

| שאלה | תשובה | הניסוח הנכון |
|---|---|---|
| 1 | D | enter |
| 2 | C | because |
| 3 | A | assess |
| 4 | B | consistent |
| 5 | C | in case |
| 6 | D | compromise |
| 7 | A | so |
| 8 | C | ask |
| 9 | A | confusing |
| 10 | C | due to |
| 11 | A | prematurely |
| 12 | C | distinguish |
| 13 | B | Why coral reefs are important and why they are at risk. |
| 14 | B | Small animals called corals. |
| 15 | D | They break the force of large waves before they reach the shore. |
| 16 | C | They can lose their color and may die if the heat continues. |
| 17 | A | Pollution and overfishing. |
| 18 | B | You can get your money back from the store just when the product is defective. |
| 19 | C | A lot of experts think the economy will improve at a gradual pace. |
| 20 | A | During the test, the students were permitted to use a dictionary. |
| 21 | A | His nervousness grew as the waiting continued. |
| 22 | B | Every summer, the festival draws thousands of tourists. |
| 23 | C | A previous arrangement prevented him from coming to the meeting. |
| 24 | C | exercise |
| 25 | D | so |
| 26 | B | in order to |
| 27 | D | remarkable |
| 28 | A | inconsistent |
| 29 | B | unanimously |

## הסברים

**1.** Enter = להיכנס. דרכון נדרש כדי להיכנס למדינה אחרת.

**2.** שנת התינוק היא הסיבה לדבר בשקט: because.

**3.** Assess = להעריך. המורה יעריך את התלמידים לפי התקדמותם.

**4.** Consistent with = עולה בקנה אחד עם. התוצאות תאמו את ההשערה.

**5.** In case = למקרה ש. שומרים מסמך למקרה שהעבודה תאבד.

**6.** Compromise = להתפשר. אם המו"מ קרס, אף צד לא היה מוכן להתפשר.

**7.** הקפה הקר הוא הסיבה; שתייה מהירה היא התוצאה: so.

**8.** Ask questions = לשאול שאלות. הרמת ידיים מאפשרת לשאול.

**9.** אם איש לא הבין, ההוראות היו "מבלבלות" (confusing).

**10.** Due to = בשל. הרוחות החזקות הן הסיבה לקריסת הגשר.

**11.** Prematurely = בטרם עת. הניגוד "Although ... promising" מרמז על מסקנה נמהרת.

**12.** Distinguish = להבחין. ההיסטוריון הקפיד להבחין בין עובדה לספקולציה.

**13.** הקטע מסביר מדוע שוניות האלמוגים חשובות ומדוע הן בסכנה.

**14.** נכתב: "These reefs are built by small animals called corals".

**15.** נכתב: "Reefs also protect coastlines by breaking the force of large waves before they reach the shore".

**16.** נכתב: "When the water becomes too warm, corals can lose their color and, if the heat continues, may die".

**17.** נכתב: "Pollution and overfishing add further pressure".

**18.** "only if the product is faulty" = רק אם המוצר פגום. התשובה הנכונה שומרת על "just when the product is defective".

**19.** Recover slowly = יתאושש לאט. התשובה הנכונה שומרת על "improve at a gradual pace".

**20.** Allow = להתיר. התשובה הנכונה שומרת על "were permitted to use a dictionary during the test".

**21.** "The longer ..., the more ..." מבטא קשר עולה. התשובה הנכונה שומרת על "nervousness grew as the waiting continued".

**22.** Attract = למשוך. התשובה הנכונה שומרת על "draws thousands of tourists every summer".

**23.** "due to a prior commitment" = בגלל התחייבות קודמת. התשובה הנכונה שומרת על "a previous arrangement prevented him from coming".

**24.** Exercise = להתעמל. התעמלות סדירה משפרת בריאות.

**25.** החשכה היא הסיבה; הדלקת האור היא התוצאה: so.

**26.** In order to = כדי ל. המתנדבים עבדו קשה כדי לשפר את הקהילה.

**27.** Remarkable = יוצא דופן. תגלית יוצאת דופן ששינתה את התחום.

**28.** Inconsistent = לא עקבי. אם זה הטיל ספק במקרה, העדות הייתה סותרת.

**29.** Unanimously = פה אחד. "only minor reservations" מתאים לאישור גורף.
