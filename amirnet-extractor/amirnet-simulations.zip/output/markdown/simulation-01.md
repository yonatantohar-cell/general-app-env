# סימולציה 1 — קל עד בינוני

סימולציה בשישה פרקי הליבה של האמירנט — השלמת משפטים, הבנת הנקרא וניסוח מחדש — ברמה קלה עד בינונית, מתאימה לתחילת התרגול.

**רמה:** קל  
**שאלות במאגר:** 29  
**מוגשות בסימולציה:** 23  
**זמן:** 39 דקות  
**מקור:** https://amirnetwords.com/tests/test-01/play

> הסימולציה מגישה 23 שאלות מתוך מאגר של 29, ובוחרת אותן באופן מסתגל. כאן מופיע המאגר המלא.

---

## פרק 1 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 1.

Despite the heavy rain, the outdoor concert was not \_\_\_\_.

**A.** created  
**B.** collected  
**C.** compared  
**D.** cancelled

#### 2.

Knowing two languages is a real \_\_\_\_ when you travel abroad.

**A.** advantage  
**B.** damage  
**C.** device  
**D.** silence

#### 3.

She was very tired, \_\_\_\_ she finished all her homework.

**A.** but  
**B.** so  
**C.** because  
**D.** and

#### 4.

Please \_\_\_\_ your seatbelt before the plane takes off.

**A.** delete  
**B.** borrow  
**C.** fasten  
**D.** measure

#### 5.

He spoke very \_\_\_\_, so everyone could hear him clearly.

**A.** quietly  
**B.** loudly  
**C.** slowly  
**D.** sadly

#### 6.

The committee will \_\_\_\_ the proposal before making a final decision.

**A.** eliminate  
**B.** evaluate  
**C.** exaggerate  
**D.** evacuate

## פרק 2 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 7.

Statistics clearly \_\_\_\_ that flying is safer than driving.

**A.** cry  
**B.** burn  
**C.** stress  
**D.** show

#### 8.

This medicine can \_\_\_\_ your pain, but take it carefully.

**A.** reduce  
**B.** inhabit  
**C.** elect  
**D.** depict

#### 9.

We need to buy more milk \_\_\_\_ we have run out.

**A.** although  
**B.** but  
**C.** or  
**D.** because

#### 10.

A doctor must \_\_\_\_ each patient carefully before treatment.

**A.** ignore  
**B.** invent  
**C.** examine  
**D.** forget

#### 11.

The new policy was introduced \_\_\_\_ reducing traffic in the city center.

**A.** in spite of  
**B.** instead of  
**C.** with the aim of  
**D.** on behalf of

#### 12.

Prices rose sharply; \_\_\_\_, demand for the product fell.

**A.** consequently  
**B.** similarly  
**C.** meanwhile  
**D.** otherwise

## פרק 3 — הבנת הנקרא

*5 שאלות בסימולציה · 5 במאגר · 15 דקות*

קראו את הקטע האקדמי הקצר ולאחר מכן ענו על השאלות הנוגעות אליו. כל התשובות מתבססות על המידע שבטקסט בלבד.

### קטע הקריאה: The Honeybee Dance

> Honeybees live together in large groups called colonies. When a bee finds a good source of food, such as a field of flowers, it returns to the hive and shares the news with the other bees. It does this by moving in a special pattern that scientists call a "waggle dance." The direction of the dance tells the other bees which way to fly, and the length of the dance tells them how far away the food is. This simple system allows thousands of bees to work together without speaking. Because of the waggle dance, a single hive can collect food from a very wide area. Scientists find the dance fascinating because it shows that even small animals can share detailed information in a clear and useful way.

#### 13.

What is the main topic of the passage?

**A.** How honeybees build their hives.  
**B.** How honeybees tell each other where to find food.  
**C.** Why honeybees prefer certain flowers.  
**D.** How scientists keep bees as pets.

#### 14.

According to the passage, what does the direction of the dance tell other bees?

**A.** How many flowers are in the field.  
**B.** How long the food will last.  
**C.** Which bee found the food.  
**D.** Which way they should fly to reach the food.

#### 15.

The length of the dance shows the other bees:

**A.** how sweet the food is.  
**B.** how many bees are dancing.  
**C.** how cold the weather is.  
**D.** how far away the food is.

#### 16.

What does the word "colonies" mean in the passage?

**A.** Special kinds of flowers.  
**B.** Tools used by scientists.  
**C.** Large groups of bees living together.  
**D.** Long flights made by single bees.

#### 17.

Why can a single hive collect food from a wide area?

**A.** Because each bee flies alone without help.  
**B.** Because the hive moves from place to place.  
**C.** Because flowers grow only near the hive.  
**D.** Because the dance lets many bees share useful information.

## פרק 4 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 18.

Although it was expensive, they decided to buy the house.

**A.** They did not buy the house because it was expensive.  
**B.** They bought the house even though it cost a lot.  
**C.** They bought the house because it was cheap.  
**D.** They are still deciding whether to buy the house.

#### 19.

She finished her homework before she went out to play.

**A.** She completed her homework first, and then she went out to play.  
**B.** She went out to play before doing her homework.  
**C.** She played outside instead of doing her homework.  
**D.** She did her homework while she was playing outside.

#### 20.

The store closes at nine, so we still have time to shop.

**A.** The store is already closed, so we cannot shop.  
**B.** We have no time left because the store closes early.  
**C.** The store closes at nine, but we do not want to shop.  
**D.** Because the store stays open until nine, we are not too late to shop.

## פרק 5 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 21.

He rarely eats fast food because he wants to stay healthy.

**A.** He almost never eats fast food in order to keep himself healthy.  
**B.** He often eats fast food even though he wants to be healthy.  
**C.** He eats fast food because it is healthy.  
**D.** He stopped caring about staying healthy.

#### 22.

The meeting was postponed until next week.

**A.** The meeting was cancelled completely.  
**B.** The meeting was moved to a later date, next week.  
**C.** The meeting happened earlier than planned.  
**D.** The meeting will take place today as planned.

#### 23.

If you practice every day, your English will improve.

**A.** Your English will get worse if you practice daily.  
**B.** Practicing daily will make your English better.  
**C.** Practicing once a week is enough to improve your English.  
**D.** Your English will improve even if you never practice.

## פרק 6 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 24.

I forgot to \_\_\_\_ the door, so the cat ran outside.

**A.** compare  
**B.** conduct  
**C.** create  
**D.** close

#### 25.

The teacher asked the students to \_\_\_\_ quietly during the exam.

**A.** shout  
**B.** work  
**C.** sleep  
**D.** argue

#### 26.

The shop is closed today, \_\_\_\_ we will come back tomorrow.

**A.** but  
**B.** although  
**C.** unless  
**D.** so

#### 27.

The weather was sunny, \_\_\_\_ we decided to go to the beach.

**A.** but  
**B.** so  
**C.** because  
**D.** although

#### 28.

Although the experiment failed, the researchers gained \_\_\_\_ insights.

**A.** worthless  
**B.** valuable  
**C.** careless  
**D.** harmful

#### 29.

The teacher praised the essay for its \_\_\_\_ and original argument.

**A.** clarity  
**B.** confusion  
**C.** cruelty  
**D.** curiosity

---

## מפתח תשובות

| שאלה | תשובה | הניסוח הנכון |
|---|---|---|
| 1 | D | cancelled |
| 2 | A | advantage |
| 3 | A | but |
| 4 | C | fasten |
| 5 | B | loudly |
| 6 | B | evaluate |
| 7 | D | show |
| 8 | A | reduce |
| 9 | D | because |
| 10 | C | examine |
| 11 | C | with the aim of |
| 12 | A | consequently |
| 13 | B | How honeybees tell each other where to find food. |
| 14 | D | Which way they should fly to reach the food. |
| 15 | D | how far away the food is. |
| 16 | C | Large groups of bees living together. |
| 17 | D | Because the dance lets many bees share useful information. |
| 18 | B | They bought the house even though it cost a lot. |
| 19 | A | She completed her homework first, and then she went out to play. |
| 20 | D | Because the store stays open until nine, we are not too late to shop. |
| 21 | A | He almost never eats fast food in order to keep himself healthy. |
| 22 | B | The meeting was moved to a later date, next week. |
| 23 | B | Practicing daily will make your English better. |
| 24 | D | close |
| 25 | B | work |
| 26 | D | so |
| 27 | B | so |
| 28 | B | valuable |
| 29 | A | clarity |

## הסברים

**1.** המילה Despite מציינת ניגוד: למרות הגשם האירוע התקיים, ולכן הפועל המתאים הוא cancelled (בוטל).

**2.** Advantage פירושו יתרון. ידיעת שתי שפות היא יתרון בנסיעות לחו"ל.

**3.** יש ניגוד בין עייפות לבין סיום השיעורים, ולכן מילת הקישור היא but (אבל).

**4.** Fasten = לחגור/להדק. חוגרים חגורת בטיחות לפני המראה.

**5.** אם כולם שמעו בבירור, הוא דיבר "בקול רם" (loudly). Quietly הוא ההפך.

**6.** Evaluate = להעריך/לבחון. הוועדה תבחן את ההצעה לפני החלטה.

**7.** נתונים סטטיסטיים "מראים" (show) משהו. הפעלים האחרים אינם משתלבים עם statistics.

**8.** Reduce = להפחית. תרופה מפחיתה כאב; שאר הפעלים אינם מתאימים להקשר.

**9.** המשפט מסביר סיבה: צריך לקנות חלב כי הוא נגמר. Because מציינת סיבה.

**10.** Examine = לבדוק. רופא בודק מטופל לפני טיפול; שאר הפעלים סותרים את ההיגיון.

**11.** with the aim of = במטרה ל. המדיניות הוצגה במטרה להפחית עומסי תנועה.

**12.** Consequently = כתוצאה מכך. עליית מחירים גרמה לירידה בביקוש.

**13.** הקטע כולו עוסק באופן שבו דבורים מודיעות זו לזו היכן נמצא מזון באמצעות "ריקוד הנדנוד".

**14.** בקטע נכתב במפורש: "The direction of the dance tells the other bees which way to fly".

**15.** נכתב: "the length of the dance tells them how far away the food is".

**16.** המשפט הראשון מסביר: "large groups called colonies", כלומר קבוצות גדולות של דבורים.

**17.** הקטע מקשר בין הריקוד המשותף ליכולת לאסוף מזון משטח רחב: "Because of the waggle dance, a single hive can collect food from a very wide area".

**18.** המשפט מציין ניגוד: למרות המחיר הגבוה הם קנו. התשובה הנכונה שומרת על "even though it cost a lot" ועל העובדה שקנו.

**19.** "before" קובע סדר זמנים: קודם השיעורים ואז המשחק. התשובה הנכונה שומרת על הסדר הזה.

**20.** המשפט אומר שיש עדיין זמן כי החנות פתוחה עד תשע. התשובה הנכונה שומרת על הסיבה והתוצאה.

**21.** "rarely" פירושו כמעט אף פעם לא. התשובה הנכונה שומרת על המשמעות ועל הסיבה (בריאות).

**22.** Postpone = לדחות למועד מאוחר יותר. התשובה הנכונה שומרת על "moved to a later date".

**23.** תרגול יומי גורם לשיפור. התשובה הנכונה שומרת על הקשר בין "daily practice" ל-"better English".

**24.** דלת "סוגרים" (close). אם שכחו לסגור, החתול ברח החוצה, זה ההיגיון של המשפט.

**25.** בזמן מבחן מבקשים מהתלמידים "לעבוד" (work) בשקט. שאר הפעלים סותרים את "quietly".

**26.** So מציינת תוצאה: מכיוון שהחנות סגורה, נחזור מחר.

**27.** מזג אוויר שמשי הוא הסיבה ללכת לים, ולכן התוצאה מסומנת ב-so.

**28.** הניגוד עם "failed" ועם "gained insights" מחייב מילה חיובית: valuable (יקרי ערך).

**29.** Clarity = בהירות. מסה משובחת על בהירות וטיעון מקורי.
