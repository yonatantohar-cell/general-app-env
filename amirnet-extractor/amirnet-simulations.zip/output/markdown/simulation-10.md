# סימולציה 10 — בינוני

סימולציה בשישה פרקי הליבה של האמירנט ברמה בינונית, המשלבת אוצר מילים אקדמי ומבני משפט מורכבים יותר.

**רמה:** בינוני  
**שאלות במאגר:** 29  
**מוגשות בסימולציה:** 23  
**זמן:** 39 דקות  
**מקור:** https://amirnetwords.com/tests/test-10/play

> הסימולציה מגישה 23 שאלות מתוך מאגר של 29, ובוחרת אותן באופן מסתגל. כאן מופיע המאגר המלא.

---

## פרק 1 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 1.

Please \_\_\_\_ the rules before you start the game.

**A.** ride  
**B.** rent  
**C.** read  
**D.** ring

#### 2.

We should \_\_\_\_ our neighbors and help them when needed.

**A.** reject  
**B.** remove  
**C.** respect  
**D.** rewind

#### 3.

The proposal was accepted \_\_\_\_ a few minor changes.

**A.** without  
**B.** with  
**C.** within  
**D.** among

#### 4.

The market is \_\_\_\_ to changes in customer demand.

**A.** sensible  
**B.** sensitive  
**C.** senseless  
**D.** separate

#### 5.

His tone was \_\_\_\_, masking the seriousness of the underlying message.

**A.** somber  
**B.** solemn  
**C.** severe  
**D.** lighthearted

#### 6.

The economist warned that the boom was \_\_\_\_ and could not last.

**A.** unsustainable  
**B.** inevitable  
**C.** irreversible  
**D.** indispensable

## פרק 2 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 7.

The team practiced daily \_\_\_\_ win the championship.

**A.** so  
**B.** because  
**C.** to  
**D.** but

#### 8.

He turned off his phone \_\_\_\_ he could focus on studying.

**A.** but  
**B.** so  
**C.** because  
**D.** although

#### 9.

The research focuses \_\_\_\_ the effects of sleep on learning.

**A.** on  
**B.** at  
**C.** in  
**D.** to

#### 10.

Despite his efforts, the project did not \_\_\_\_ as planned.

**A.** precede  
**B.** predict  
**C.** proceed  
**D.** prepare

#### 11.

The theory gained \_\_\_\_ once independent studies replicated the results.

**A.** credibility  
**B.** credulity  
**C.** curiosity  
**D.** creativity

#### 12.

Far from being trivial, the discovery had \_\_\_\_ implications for medicine.

**A.** minor  
**B.** profound  
**C.** negligible  
**D.** trivial

## פרק 3 — הבנת הנקרא

*5 שאלות בסימולציה · 5 במאגר · 15 דקות*

קראו את הקטע האקדמי הקצר ולאחר מכן ענו על השאלות הנוגעות אליו. כל התשובות מתבססות על המידע שבטקסט בלבד.

### קטע הקריאה: The Science of Sleep

> Sleep may look like a time when the body does nothing, but in fact a great deal happens during these hours. While we sleep, the brain sorts through the events of the day and strengthens the memories worth keeping. The body also repairs tissues, builds energy, and supports the systems that fight illness. People who regularly sleep too little often struggle to concentrate and may become more easily upset. Over many years, poor sleep has been linked to a range of health problems. Despite this, many adults treat sleep as something they can cut whenever they are busy. Researchers warn that this is a mistake. Although the right amount of sleep varies from person to person, most adults need around seven to eight hours each night. Rather than a waste of time, sleep is one of the most active and useful parts of a healthy life.

#### 13.

What is the main idea of the passage?

**A.** Sleep is an active and important process, not wasted time.  
**B.** The body does nothing useful during sleep.  
**C.** People should sleep as little as possible.  
**D.** Memory has no connection to sleep.

#### 14.

According to the passage, what does the brain do during sleep?

**A.** It deletes all of the day’s memories.  
**B.** It sorts through the day and strengthens useful memories.  
**C.** It completely stops working.  
**D.** It learns new languages on its own.

#### 15.

What does the body do during sleep, according to the passage?

**A.** It grows new bones every night.  
**B.** It uses far more energy than when awake.  
**C.** It repairs tissues, builds energy, and supports the systems that fight illness.  
**D.** It stops fighting illness completely.

#### 16.

What often happens to people who regularly sleep too little?

**A.** They concentrate better than other people.  
**B.** They never feel tired during the day.  
**C.** They struggle to concentrate and may become easily upset.  
**D.** They no longer need to eat.

#### 17.

How much sleep do most adults need each night, according to the passage?

**A.** Around seven to eight hours.  
**B.** Exactly four hours.  
**C.** More than twelve hours.  
**D.** Less than two hours.

## פרק 4 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 18.

The new software is easier to use than the previous version.

**A.** The previous version is easier to use than the new software.  
**B.** Both versions of the software are equally hard to use.  
**C.** Compared with the older version, the new software is simpler to operate.  
**D.** The new software is harder to use than the old one.

#### 19.

The volunteers cleaned the beach so that families could enjoy it.

**A.** The volunteers left the beach dirty for the families.  
**B.** Families cleaned the beach for the volunteers to enjoy.  
**C.** The volunteers cleaned the beach but kept families away.  
**D.** The volunteers cleared the beach in order for families to enjoy it.

#### 20.

Sales increased significantly after the price was lowered.

**A.** Sales fell sharply after the price was lowered.  
**B.** Once the price dropped, sales rose sharply.  
**C.** The price rose, and sales increased significantly.  
**D.** Lowering the price had no effect on sales.

## פרק 5 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 21.

The professor encouraged students to ask questions freely.

**A.** The professor told students not to ask any questions.  
**B.** The professor asked the students many questions himself.  
**C.** The professor urged students to feel free to ask questions.  
**D.** The professor allowed questions only at the end of the year.

#### 22.

Despite the warnings, many people ignored the safety rules.

**A.** Because of the warnings, everyone followed the safety rules.  
**B.** There were no warnings, so people ignored the rules.  
**C.** Even though they were warned, many people did not follow the safety rules.  
**D.** People followed the safety rules despite the warnings.

#### 23.

The book became popular thanks to word of mouth.

**A.** The book became popular because of expensive advertising.  
**B.** Word of mouth made the book unpopular.  
**C.** People recommending it to one another made the book popular.  
**D.** The book stayed unknown despite word of mouth.

## פרק 6 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 24.

The juice was sweet \_\_\_\_ a little sour at the same time.

**A.** so  
**B.** because  
**C.** but  
**D.** until

#### 25.

The lecture covered a wide \_\_\_\_ of topics.

**A.** range  
**B.** rank  
**C.** rate  
**D.** rage

#### 26.

The teacher repeated the rule \_\_\_\_ everyone would remember it.

**A.** in spite of  
**B.** rather than  
**C.** so that  
**D.** as well as

#### 27.

The data clearly \_\_\_\_ a link between diet and health.

**A.** imitates  
**B.** invites  
**C.** indicates  
**D.** invents

#### 28.

The instructions were deliberately \_\_\_\_ to allow for flexible interpretation.

**A.** explicit  
**B.** definite  
**C.** ambiguous  
**D.** precise

#### 29.

The argument is persuasive \_\_\_\_ it ignores several important objections.

**A.** insofar as  
**B.** provided that  
**C.** in case  
**D.** so that

---

## מפתח תשובות

| שאלה | תשובה | הניסוח הנכון |
|---|---|---|
| 1 | C | read |
| 2 | C | respect |
| 3 | B | with |
| 4 | B | sensitive |
| 5 | D | lighthearted |
| 6 | A | unsustainable |
| 7 | C | to |
| 8 | B | so |
| 9 | A | on |
| 10 | C | proceed |
| 11 | A | credibility |
| 12 | B | profound |
| 13 | A | Sleep is an active and important process, not wasted time. |
| 14 | B | It sorts through the day and strengthens useful memories. |
| 15 | C | It repairs tissues, builds energy, and supports the systems that fight illness. |
| 16 | C | They struggle to concentrate and may become easily upset. |
| 17 | A | Around seven to eight hours. |
| 18 | C | Compared with the older version, the new software is simpler to operate. |
| 19 | D | The volunteers cleared the beach in order for families to enjoy it. |
| 20 | B | Once the price dropped, sales rose sharply. |
| 21 | C | The professor urged students to feel free to ask questions. |
| 22 | C | Even though they were warned, many people did not follow the safety rules. |
| 23 | C | People recommending it to one another made the book popular. |
| 24 | C | but |
| 25 | A | range |
| 26 | C | so that |
| 27 | C | indicates |
| 28 | C | ambiguous |
| 29 | A | insofar as |

## הסברים

**1.** חוקים "קוראים" (read) לפני שמתחילים משחק.

**2.** Respect = לכבד. ראוי לכבד ולעזור לשכנים.

**3.** With = עם. ההצעה התקבלה עם מספר שינויים קלים.

**4.** Sensitive to = רגיש ל. השוק רגיש לשינויים בביקוש.

**5.** Lighthearted = קליל. אם זה הסתיר רצינות, הטון היה קליל.

**6.** Unsustainable = בלתי-בר-קיימא. "could not last" מתאים בדיוק לכך.

**7.** to + פועל מציין מטרה: התאמנו כדי לזכות באליפות.

**8.** So that כאן מקוצר ל-so ומציין מטרה/תוצאה: כיבה את הטלפון כדי להתרכז.

**9.** Focus on = להתמקד ב. המחקר מתמקד בהשפעות השינה על הלמידה.

**10.** Proceed = להתקדם. למרות המאמצים, הפרויקט לא התקדם כמתוכנן.

**11.** Credibility = אמינות. שכפול עצמאי של תוצאות מקנה אמינות.

**12.** Profound = עמוק/מרחיק לכת. "Far from being trivial" מחייב מילה הפוכה ל-trivial.

**13.** הרעיון המרכזי: השינה היא תהליך פעיל וחשוב, ולא בזבוז זמן.

**14.** נכתב: "the brain sorts through the events of the day and strengthens the memories worth keeping".

**15.** נכתב: "the body also repairs tissues, builds energy, and supports the systems that fight illness".

**16.** נכתב: "People who regularly sleep too little often struggle to concentrate and may become more easily upset".

**17.** נכתב: "most adults need around seven to eight hours each night".

**18.** התשובה הנכונה שומרת על ההשוואה: החדש פשוט יותר מהגרסה הקודמת.

**19.** הניקיון נועד לאפשר למשפחות ליהנות. התשובה הנכונה שומרת על "in order for families to enjoy it".

**20.** הורדת המחיר הובילה לעלייה במכירות. התשובה הנכונה שומרת על הסיבה (price dropped) והתוצאה (sales rose sharply).

**21.** Encourage = לעודד. התשובה הנכונה שומרת על "urged students to feel free to ask questions".

**22.** יש ניגוד בין האזהרות להתעלמות. התשובה הנכונה שומרת על "even though they were warned, many ... did not follow the rules".

**23.** "thanks to word of mouth" = הודות להמלצות בעל פה. התשובה הנכונה שומרת על "people recommending it to one another made the book popular".

**24.** יש ניגוד בין מתוק לחמוץ, ולכן but.

**25.** A wide range of = מגוון רחב של. ההרצאה כיסתה מגוון רחב של נושאים.

**26.** So that = כדי ש. המורה חזר על הכלל כדי שכולם יזכרו.

**27.** Indicate = להצביע על. הנתונים מצביעים על קשר בין תזונה לבריאות.

**28.** Ambiguous = דו-משמעי. כדי לאפשר פרשנות גמישה, ההוראות נוסחו במכוון בעמימות.

**29.** Insofar as = במידה ש. הטיעון משכנע במידה שהוא מתעלם מהתנגדויות.
