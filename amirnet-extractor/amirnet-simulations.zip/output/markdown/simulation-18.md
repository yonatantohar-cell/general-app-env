# סימולציה 18 — קשה

סימולציה מאתגרת בשישה פרקי הליבה של האמירנט, ברמה גבוהה ומיועדת למי שמכוון לציון גבוה.

**רמה:** expert  
**שאלות במאגר:** 29  
**מוגשות בסימולציה:** 23  
**זמן:** 39 דקות  
**מקור:** https://amirnetwords.com/tests/test-18/play

> הסימולציה מגישה 23 שאלות מתוך מאגר של 29, ובוחרת אותן באופן מסתגל. כאן מופיע המאגר המלא.

---

## פרק 1 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 1.

The company plans to \_\_\_\_ its services to new markets.

**A.** expose  
**B.** expire  
**C.** expand  
**D.** explode

#### 2.

The reform was \_\_\_\_ because it failed to consider local conditions.

**A.** inevitable  
**B.** invaluable  
**C.** innovative  
**D.** ineffective

#### 3.

The witness recounted the events with remarkable \_\_\_\_.

**A.** accuracy  
**B.** anxiety  
**C.** ambition  
**D.** authority

#### 4.

The reform’s success \_\_\_\_ on factors outside the planners’ control.

**A.** depended  
**B.** detached  
**C.** deviated  
**D.** descended

#### 5.

His critique is \_\_\_\_, dismantling the theory point by point.

**A.** gentle  
**B.** tentative  
**C.** cautious  
**D.** devastating

#### 6.

The findings \_\_\_\_ a more cautious interpretation than the authors offer.

**A.** waive  
**B.** wander  
**C.** wither  
**D.** warrant

## פרק 2 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 7.

The committee’s recommendation was \_\_\_\_ ignored by the management.

**A.** rarely  
**B.** largely  
**C.** hardly  
**D.** scarcely

#### 8.

The conclusion is \_\_\_\_, since the premises do not actually support it.

**A.** inevitable  
**B.** unwarranted  
**C.** justified  
**D.** reasonable

#### 9.

The argument relies on a \_\_\_\_ that the two cases are truly comparable.

**A.** assertion  
**B.** assignment  
**C.** assumption  
**D.** assessment

#### 10.

The lecture \_\_\_\_ a subject that most prefer to avoid.

**A.** conceals  
**B.** confronts  
**C.** circumvents  
**D.** sidesteps

#### 11.

The reform was \_\_\_\_ in name only, leaving the system untouched.

**A.** ineffective  
**B.** marginal  
**C.** gradual  
**D.** revolutionary

#### 12.

The reform \_\_\_\_ a delicate balance between competing interests.

**A.** shatters  
**B.** severs  
**C.** spurns  
**D.** strikes

## פרק 3 — הבנת הנקרא

*5 שאלות בסימולציה · 5 במאגר · 15 דקות*

קראו את הקטע האקדמי הקצר ולאחר מכן ענו על השאלות הנוגעות אליו. כל התשובות מתבססות על המידע שבטקסט בלבד.

### קטע הקריאה: The Ethics of Predictive Algorithms

> $8

#### 13.

What is the main argument of the passage?

**A.** Predictive algorithms are perfectly objective and fair.  
**B.** Predictive algorithms should be banned entirely.  
**C.** Human judgment is always better than any algorithm.  
**D.** Predictive algorithms can reproduce past bias and must be scrutinized, not blindly trusted.

#### 14.

What is the stated appeal of predictive algorithms?

**A.** They promise faster, seemingly more objective decisions than humans.  
**B.** They remove the need for any data.  
**C.** They guarantee that no mistakes occur.  
**D.** They make all human workers unnecessary.

#### 15.

Why is true objectivity hard for these algorithms to achieve?

**A.** They are never trained on any data.  
**B.** They ignore all historical patterns.  
**C.** They are designed to be unfair on purpose.  
**D.** They absorb the patterns in historical data, including past discrimination.

#### 16.

What problem does the opacity of these systems cause?

**A.** It makes the systems run more slowly.  
**B.** It removes all bias from the systems.  
**C.** It is hard for affected people to understand or contest decisions.  
**D.** It allows everyone to see the data clearly.

#### 17.

What does the author propose as the proper response?

**A.** Abandoning the tools completely.  
**B.** Trusting the tools without question.  
**C.** Subjecting the tools to scrutiny, auditing, and transparency.  
**D.** Hiding the outcomes from the public.

## פרק 4 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 18.

The witness’s account, corroborated by physical evidence, proved compelling.

**A.** The witness’s account was rejected for lacking any evidence.  
**B.** Physical evidence contradicted the witness’s account.  
**C.** The witness’s account was convincing despite the missing evidence.  
**D.** Backed up by physical evidence, the witness’s account turned out to be convincing.

#### 19.

The policy’s benefits, considerable though they are, do not justify its costs.

**A.** Although the policy brings substantial benefits, they are not worth what it costs.  
**B.** The policy’s small benefits easily justify its costs.  
**C.** The policy’s benefits clearly outweigh its costs.  
**D.** The policy has no benefits and only heavy costs.

#### 20.

Critics contend that the model oversimplifies a fundamentally complex phenomenon.

**A.** Critics agree the model captures all the phenomenon’s complexity.  
**B.** Critics maintain that the model treats a deeply complex phenomenon too simply.  
**C.** Critics say the model makes a simple phenomenon too complicated.  
**D.** Critics ignore how the model handles the phenomenon.

## פרק 5 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 21.

Notwithstanding its initial appeal, the scheme soon revealed serious shortcomings.

**A.** Because it looked attractive, the scheme proved flawless.  
**B.** The scheme had no appeal and no shortcomings.  
**C.** The scheme’s weaknesses appeared before it was launched.  
**D.** In spite of how attractive it looked at first, the scheme quickly showed major weaknesses.

#### 22.

The findings underscore the extent to which environment shapes behaviour.

**A.** The findings show that environment has little effect on behaviour.  
**B.** The findings prove that behaviour shapes the environment.  
**C.** The findings highlight just how much the surroundings influence behaviour.  
**D.** The findings ignore the link between environment and behaviour.

#### 23.

The proposal was met with skepticism, if not outright hostility.

**A.** The proposal was welcomed with great enthusiasm.  
**B.** The proposal was received with doubt, and at times even open hostility.  
**C.** The proposal was accepted without any doubt at all.  
**D.** The proposal was met with friendliness rather than doubt.

## פרק 6 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 24.

The two outcomes are \_\_\_\_ different despite identical starting points.

**A.** strikingly  
**B.** slightly  
**C.** barely  
**D.** remotely

#### 25.

The technology is \_\_\_\_ in theory but rarely used in practice.

**A.** available  
**B.** absent  
**C.** forbidden  
**D.** obsolete

#### 26.

The data were \_\_\_\_, pointing in two opposite directions at once.

**A.** unambiguous  
**B.** definitive  
**C.** equivocal  
**D.** transparent

#### 27.

The two explanations are not rivals but \_\_\_\_ accounts of one process.

**A.** complementary  
**B.** conflicting  
**C.** contradictory  
**D.** competing

#### 28.

The argument \_\_\_\_ under the weight of its own contradictions.

**A.** flourishes  
**B.** collapses  
**C.** consolidates  
**D.** crystallizes

#### 29.

The evidence is \_\_\_\_ enough to justify further, but not final, study.

**A.** conclusive  
**B.** exhaustive  
**C.** definitive  
**D.** suggestive

---

## מפתח תשובות

| שאלה | תשובה | הניסוח הנכון |
|---|---|---|
| 1 | C | expand |
| 2 | D | ineffective |
| 3 | A | accuracy |
| 4 | A | depended |
| 5 | D | devastating |
| 6 | D | warrant |
| 7 | B | largely |
| 8 | B | unwarranted |
| 9 | C | assumption |
| 10 | B | confronts |
| 11 | D | revolutionary |
| 12 | D | strikes |
| 13 | D | Predictive algorithms can reproduce past bias and must be scrutinized, not blindly trusted. |
| 14 | A | They promise faster, seemingly more objective decisions than humans. |
| 15 | D | They absorb the patterns in historical data, including past discrimination. |
| 16 | C | It is hard for affected people to understand or contest decisions. |
| 17 | C | Subjecting the tools to scrutiny, auditing, and transparency. |
| 18 | D | Backed up by physical evidence, the witness’s account turned out to be convincing. |
| 19 | A | Although the policy brings substantial benefits, they are not worth what it costs. |
| 20 | B | Critics maintain that the model treats a deeply complex phenomenon too simply. |
| 21 | D | In spite of how attractive it looked at first, the scheme quickly showed major weaknesses. |
| 22 | C | The findings highlight just how much the surroundings influence behaviour. |
| 23 | B | The proposal was received with doubt, and at times even open hostility. |
| 24 | A | strikingly |
| 25 | A | available |
| 26 | C | equivocal |
| 27 | A | complementary |
| 28 | B | collapses |
| 29 | D | suggestive |

## הסברים

**1.** Expand = להרחיב. החברה מתכננת להרחיב שירותים לשווקים חדשים.

**2.** Ineffective = בלתי יעיל. התעלמות מתנאים מקומיים הופכת רפורמה לבלתי יעילה.

**3.** Accuracy = דיוק. "recounted the events" מתאים לתיאור מדויק.

**4.** Depend on = להיות תלוי ב. ההצלחה הייתה תלויה בגורמים חיצוניים.

**5.** Devastating = הרסני/מוחץ. פירוק התאוריה נקודה אחר נקודה מצביע על ביקורת מוחצת.

**6.** Warrant = להצדיק/לחייב. הממצאים מצדיקים פרשנות זהירה יותר.

**7.** Largely = במידה רבה. ההנהלה התעלמה במידה רבה מההמלצה.

**8.** Unwarranted = בלתי מוצדק. אם ההנחות אינן תומכות, המסקנה אינה מוצדקת.

**9.** Assumption = הנחה. הטיעון מסתמך על ההנחה שהמקרים דומים.

**10.** Confront = להתמודד עם. הניגוד מול "prefer to avoid" מחייב פועל של התמודדות.

**11.** "revolutionary in name only", מהפכנית בשם בלבד. הניגוד מול "untouched" מחייב מילה גדולה.

**12.** Strike a balance = ליצור איזון. הרפורמה יוצרת איזון עדין בין אינטרסים מתחרים.

**13.** הטיעון המרכזי: אלגוריתמים חזויים עלולים לשכפל הטיות מהעבר ויש לבחון אותם, לא לבטוח בהם בעיניים עצומות.

**14.** נכתב: "they promise to replace inconsistent human judgment with something faster and ostensibly more objective".

**15.** נכתב: "An algorithm trained on historical data inevitably absorbs the patterns embedded in that data, including patterns that reflect past discrimination".

**16.** נכתב: "many such systems are opaque, making it hard for those affected to understand or contest the decisions".

**17.** נכתב: "The proper response is not to abandon these tools ... but to subject them to scrutiny: auditing their outcomes, demanding transparency".

**18.** Corroborate = לאשש; compelling = משכנע. התשובה הנכונה שומרת על "backed up by physical evidence ... convincing".

**19.** "considerable though they are, do not justify its costs" = ניכרות ככל שיהיו, אינן מצדיקות את העלות. התשובה הנכונה שומרת על הוויתור ועל המסקנה.

**20.** Contend = לטעון; oversimplify = לפשט יתר על המידה. התשובה הנכונה שומרת על "treats a deeply complex phenomenon too simply".

**21.** Notwithstanding = על אף; shortcomings = ליקויים. התשובה הנכונה שומרת על "in spite of how attractive it looked ... showed major weaknesses".

**22.** "underscore the extent to which environment shapes behaviour" = מדגישות עד כמה הסביבה מעצבת התנהגות. התשובה הנכונה שומרת על המשמעות והכיוון.

**23.** "skepticism, if not outright hostility" = ספקנות, ולעיתים אף עוינות גלויה. התשובה הנכונה שומרת על "doubt, and at times even open hostility".

**24.** Strikingly = באופן בולט. נקודות פתיחה זהות מדגישות הבדל בולט.

**25.** הניגוד "in theory but rarely in practice" מחייב מילה חיובית: available (זמינה).

**26.** Equivocal = דו-משמעי. נתונים המצביעים לשני כיוונים הם דו-משמעיים.

**27.** Complementary = משלימים. "not rivals but" מחייב יחס משלים בין ההסברים.

**28.** Collapse = להתמוטט. סתירות פנימיות גורמות לטיעון להתמוטט.

**29.** Suggestive = מרמז/מעורר. ראיה שמצדיקה מחקר נוסף אך לא סופית היא מרמזת בלבד.
