# סימולציה 4 — קל עד בינוני

סימולציה בשישה פרקי הליבה של האמירנט — השלמת משפטים, הבנת הנקרא וניסוח מחדש — ברמה קלה עד בינונית, מתאימה לתחילת התרגול.

**רמה:** קל  
**שאלות במאגר:** 29  
**מוגשות בסימולציה:** 23  
**זמן:** 39 דקות  
**מקור:** https://amirnetwords.com/tests/test-04/play

> הסימולציה מגישה 23 שאלות מתוך מאגר של 29, ובוחרת אותן באופן מסתגל. כאן מופיע המאגר המלא.

---

## פרק 1 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 1.

Wear comfortable shoes \_\_\_\_ we will walk a lot today.

**A.** but  
**B.** although  
**C.** so  
**D.** because

#### 2.

The instructions were \_\_\_\_, so the task was easy to do.

**A.** unclear  
**B.** clear  
**C.** cloudy  
**D.** crooked

#### 3.

Take an umbrella \_\_\_\_ it might rain later.

**A.** so  
**B.** but  
**C.** because  
**D.** although

#### 4.

Plants need water and sunlight to \_\_\_\_.

**A.** glow  
**B.** grab  
**C.** greet  
**D.** grow

#### 5.

The data was unclear, \_\_\_\_ we repeated the experiment.

**A.** therefore  
**B.** however  
**C.** nevertheless  
**D.** although

#### 6.

The company aims to \_\_\_\_ its profits over the next year.

**A.** increase  
**B.** decrease  
**C.** release  
**D.** replace

## פרק 2 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 7.

The chef will \_\_\_\_ a special dish for the guests.

**A.** count  
**B.** clean  
**C.** cut  
**D.** cook

#### 8.

We turned on the heater \_\_\_\_ the room was cold.

**A.** because  
**B.** so  
**C.** although  
**D.** and

#### 9.

The waiter was polite and \_\_\_\_ our food quickly.

**A.** solved  
**B.** saved  
**C.** served  
**D.** sailed

#### 10.

The exam was difficult, \_\_\_\_ most students passed.

**A.** so  
**B.** but  
**C.** because  
**D.** unless

#### 11.

Good communication is \_\_\_\_ for successful teamwork.

**A.** essential  
**B.** optional  
**C.** temporary  
**D.** doubtful

#### 12.

He kept calm \_\_\_\_ the situation became very stressful.

**A.** even when  
**B.** so that  
**C.** in order to  
**D.** as well as

## פרק 3 — הבנת הנקרא

*5 שאלות בסימולציה · 5 במאגר · 15 דקות*

קראו את הקטע האקדמי הקצר ולאחר מכן ענו על השאלות הנוגעות אליו. כל התשובות מתבססות על המידע שבטקסט בלבד.

### קטע הקריאה: Why We Yawn

> Almost everyone yawns, yet for a long time no one was sure why. A yawn is a deep breath in which the mouth opens wide and air fills the lungs. People often yawn when they are tired or bored, but they also yawn at other times. One popular idea is that yawning helps cool the brain. When the brain becomes a little too warm, a yawn brings in cool air and may help it work better. Another interesting fact is that yawning seems to spread from person to person. If one person in a room yawns, others often yawn soon after, even if they are not tired. Scientists believe this "catching" of yawns may be linked to the way humans copy one another. Although we still do not have all the answers, yawning remains a small but curious part of being human.

#### 13.

What is the passage mainly about?

**A.** How to stop yawning forever.  
**B.** Possible reasons why people yawn.  
**C.** Why people fall asleep at night.  
**D.** How the lungs are built.

#### 14.

According to the passage, what is a yawn?

**A.** A type of sneeze.  
**B.** A way of speaking quietly.  
**C.** A short sleep during the day.  
**D.** A deep breath with a wide-open mouth.

#### 15.

One popular idea in the passage is that yawning helps:

**A.** warm the lungs.  
**B.** clean the teeth.  
**C.** speed up the heart.  
**D.** cool the brain.

#### 16.

What happens when the brain becomes a little too warm?

**A.** A yawn brings in cool air that may help it work better.  
**B.** The person stops breathing for a while.  
**C.** The brain shrinks in size.  
**D.** The person feels colder all over.

#### 17.

According to the passage, yawning seems to:

**A.** happen only when people sleep.  
**B.** stop people from feeling tired.  
**C.** make people unable to talk.  
**D.** spread from one person to another.

## פרק 4 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 18.

Few people noticed the small mistake in the report.

**A.** Almost no one saw the small error in the report.  
**B.** Many people noticed the small mistake in the report.  
**C.** Everyone noticed the big mistake in the report.  
**D.** The report had no mistakes at all.

#### 19.

We can either watch a film or go for a walk.

**A.** We must both watch a film and go for a walk.  
**B.** We cannot watch a film or go for a walk.  
**C.** We have two choices: see a film or take a walk.  
**D.** We have to stay home and do nothing.

#### 20.

The shop sells fresh bread every morning.

**A.** The shop sells old bread only in the evening.  
**B.** The shop never sells bread in the morning.  
**C.** The shop sells fresh bread once a week.  
**D.** Each morning, the shop has fresh bread for sale.

## פרק 5 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 21.

He apologized because he had arrived late.

**A.** He said sorry for coming late.  
**B.** He was angry that the others arrived late.  
**C.** He refused to apologize for being late.  
**D.** He arrived early and did not need to apologize.

#### 22.

The garden looks beautiful when the flowers bloom in spring.

**A.** The garden looks ugly when the flowers bloom in spring.  
**B.** The flowers bloom in winter, not in spring.  
**C.** In spring, the blooming flowers make the garden look lovely.  
**D.** The garden has no flowers at all.

#### 23.

You must show your ticket before you enter the cinema.

**A.** You can enter the cinema without showing a ticket.  
**B.** Entry to the cinema requires you to present your ticket first.  
**C.** You show your ticket only after the film ends.  
**D.** Tickets are not needed to watch films at the cinema.

## פרק 6 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 24.

She felt happy \_\_\_\_ she had passed all her exams.

**A.** so  
**B.** but  
**C.** unless  
**D.** because

#### 25.

The dog is friendly and never \_\_\_\_ strangers.

**A.** bites  
**B.** builds  
**C.** buys  
**D.** bakes

#### 26.

I like tea, \_\_\_\_ my sister prefers coffee.

**A.** so  
**B.** because  
**C.** and  
**D.** but

#### 27.

Please \_\_\_\_ your name at the top of the page.

**A.** wait  
**B.** write  
**C.** wash  
**D.** win

#### 28.

The plan sounds good \_\_\_\_, but it may be hard to apply.

**A.** in practice  
**B.** in theory  
**C.** in person  
**D.** in time

#### 29.

The findings \_\_\_\_ the idea that exercise improves memory.

**A.** suppose  
**B.** support  
**C.** suppress  
**D.** surround

---

## מפתח תשובות

| שאלה | תשובה | הניסוח הנכון |
|---|---|---|
| 1 | D | because |
| 2 | B | clear |
| 3 | C | because |
| 4 | D | grow |
| 5 | A | therefore |
| 6 | A | increase |
| 7 | D | cook |
| 8 | A | because |
| 9 | C | served |
| 10 | B | but |
| 11 | A | essential |
| 12 | A | even when |
| 13 | B | Possible reasons why people yawn. |
| 14 | D | A deep breath with a wide-open mouth. |
| 15 | D | cool the brain. |
| 16 | A | A yawn brings in cool air that may help it work better. |
| 17 | D | spread from one person to another. |
| 18 | A | Almost no one saw the small error in the report. |
| 19 | C | We have two choices: see a film or take a walk. |
| 20 | D | Each morning, the shop has fresh bread for sale. |
| 21 | A | He said sorry for coming late. |
| 22 | C | In spring, the blooming flowers make the garden look lovely. |
| 23 | B | Entry to the cinema requires you to present your ticket first. |
| 24 | D | because |
| 25 | A | bites |
| 26 | D | but |
| 27 | B | write |
| 28 | B | in theory |
| 29 | B | support |

## הסברים

**1.** ההליכה הרבה היא הסיבה לנעול נעליים נוחות: because.

**2.** אם המשימה הייתה קלה, ההוראות היו "ברורות" (clear).

**3.** האפשרות לגשם היא הסיבה לקחת מטרייה: because.

**4.** Grow = לגדול. צמחים גדלים עם מים ושמש.

**5.** Therefore = לכן. חוסר בהירות הנתונים הוביל לחזרה על הניסוי.

**6.** Increase = להגדיל. החברה שואפת להגדיל רווחים.

**7.** מנה "מבשלים" (cook). שאר הפעלים אינם מתאימים ל-dish כאן.

**8.** הקור בחדר הוא הסיבה להדליק תנור: because.

**9.** Serve = להגיש. מלצר מגיש אוכל; שאר הפעלים אינם מתאימים.

**10.** יש ניגוד בין הקושי לבין ההצלחה, ולכן but.

**11.** Essential = חיוני. תקשורת טובה חיונית לעבודת צוות מוצלחת.

**12.** Even when = אפילו כאשר. ניגוד בין הרגיעה למצב הלחוץ.

**13.** הקטע עוסק בסיבות האפשריות לפיהוק.

**14.** נכתב: "A yawn is a deep breath in which the mouth opens wide and air fills the lungs".

**15.** נכתב: "yawning helps cool the brain".

**16.** נכתב: "a yawn brings in cool air and may help it work better".

**17.** נכתב: "yawning seems to spread from person to person".

**18.** "Few people" = כמעט אף אחד. התשובה הנכונה שומרת על "almost no one saw the small error".

**19.** "either ... or" מציג שתי אפשרויות לבחירה. התשובה הנכונה שומרת על "two choices".

**20.** התשובה הנכונה שומרת על "each morning" ועל "fresh bread for sale" בלי לשנות פרטים.

**21.** Apologize = להתנצל. התשובה הנכונה שומרת על "said sorry for coming late".

**22.** התשובה הנכונה שומרת על "blooming flowers", על "spring" ועל המראה היפה.

**23.** "must show ... before you enter" = חובה להציג כרטיס לפני הכניסה. התשובה הנכונה שומרת על "requires you to present your ticket first".

**24.** המעבר במבחנים הוא הסיבה לאושר: because.

**25.** Bite = לנשוך. כלב ידידותי אינו נושך זרים.

**26.** יש ניגוד בין ההעדפות, ולכן but.

**27.** שם "כותבים" (write). שאר הפעלים אינם מתאימים.

**28.** In theory = בתאוריה. הניגוד מול היישום הקשה מחייב "בתאוריה".

**29.** Support = לתמוך/לחזק. הממצאים תומכים ברעיון.
