# סימולציה 13 — בינוני עד קשה

סימולציה בשישה פרקי הליבה של האמירנט ברמה בינונית עד קשה, עם ניגוד, סיבה ותוצאה והבחנות דקות.

**רמה:** קשה  
**שאלות במאגר:** 29  
**מוגשות בסימולציה:** 23  
**זמן:** 39 דקות  
**מקור:** https://amirnetwords.com/tests/test-13/play

> הסימולציה מגישה 23 שאלות מתוך מאגר של 29, ובוחרת אותן באופן מסתגל. כאן מופיע המאגר המלא.

---

## פרק 1 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 1.

The results were promising, \_\_\_\_ further testing is required.

**A.** therefore  
**B.** although  
**C.** thus  
**D.** hence

#### 2.

The government introduced new laws to \_\_\_\_ pollution.

**A.** command  
**B.** comment  
**C.** combat  
**D.** commit

#### 3.

The teacher asked the class to \_\_\_\_ the two poems.

**A.** compete  
**B.** complain  
**C.** compare  
**D.** compose

#### 4.

The text is dense and requires \_\_\_\_ reading to be understood.

**A.** attentive  
**B.** careless  
**C.** casual  
**D.** hasty

#### 5.

The expansion was \_\_\_\_, limited by both budget and time.

**A.** unlimited  
**B.** constrained  
**C.** extensive  
**D.** boundless

#### 6.

The author’s claims are \_\_\_\_, blurring the line between fact and opinion.

**A.** impartial  
**B.** objective  
**C.** neutral  
**D.** tendentious

## פרק 2 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 7.

The committee will \_\_\_\_ the issue at the next meeting.

**A.** admire  
**B.** advance  
**C.** address  
**D.** adopt

#### 8.

She kept notes \_\_\_\_ she would not forget the details.

**A.** in spite of  
**B.** rather than  
**C.** so that  
**D.** as well as

#### 9.

The results were \_\_\_\_ with the hypothesis, lending it strong support.

**A.** incompatible  
**B.** consistent  
**C.** irrelevant  
**D.** inconsistent

#### 10.

The two theories, once thought \_\_\_\_, are now seen as related.

**A.** identical  
**B.** similar  
**C.** connected  
**D.** distinct

#### 11.

Her conclusions, though bold, were \_\_\_\_ by solid evidence.

**A.** undermined  
**B.** contradicted  
**C.** substantiated  
**D.** weakened

#### 12.

The study’s methodology was sound, \_\_\_\_ its sample was regrettably narrow.

**A.** even if  
**B.** so that  
**C.** in order that  
**D.** as long as

## פרק 3 — הבנת הנקרא

*5 שאלות בסימולציה · 5 במאגר · 15 דקות*

קראו את הקטע האקדמי הקצר ולאחר מכן ענו על השאלות הנוגעות אליו. כל התשובות מתבססות על המידע שבטקסט בלבד.

### קטע הקריאה: Language and Color

> The colors of the rainbow appear to be a fixed feature of the physical world, yet the way languages divide them varies considerably. Some languages use only two or three basic color terms, grouping together shades that English speakers would treat as distinct. Others draw finer distinctions, with separate words for hues that English lumps under a single label. Researchers have asked whether these differences shape how people actually perceive color. The evidence is mixed. People can usually see and distinguish far more colors than their language names, which suggests that perception is not strictly limited by vocabulary. At the same time, studies indicate that speakers may sort and remember colors slightly faster when their language provides a ready word for them. The debate illustrates a broader question in the study of language: whether the words available to us merely describe our thoughts or also, in subtle ways, help to shape them.

#### 13.

What broader question does the passage illustrate?

**A.** Whether language merely describes our thoughts or also helps shape them.  
**B.** Whether rainbows are real or imaginary.  
**C.** Whether English has the most color words.  
**D.** Whether color exists in the physical world.

#### 14.

How do languages differ in dealing with color, according to the passage?

**A.** They divide colors into different numbers of basic terms.  
**B.** They all use exactly the same color words.  
**C.** They never have words for color at all.  
**D.** They change their color words every year.

#### 15.

What does the evidence suggest about perception and vocabulary?

**A.** People see only the colors their language names.  
**B.** People can see more colors than their language names.  
**C.** Vocabulary has no effect at all on memory.  
**D.** Language fully controls what people can see.

#### 16.

According to the studies mentioned, when might speakers sort colors slightly faster?

**A.** When they have never seen the color before.  
**B.** When their language has no word for the color.  
**C.** When they are not allowed to use words.  
**D.** When their language provides a ready word for the color.

#### 17.

How does the author describe the evidence on this topic?

**A.** As completely clear and settled.  
**B.** As entirely false.  
**C.** As irrelevant to language.  
**D.** As mixed.

## פרק 4 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 18.

Whatever the cause, the consequences were severe.

**A.** The cause was clear, but the consequences were minor.  
**B.** There were no real consequences, whatever the cause.  
**C.** The consequences were severe only for a known cause.  
**D.** No matter what brought it about, the results were serious.

#### 19.

The proposal was rejected on the grounds that it was too costly.

**A.** The proposal was turned down because it was considered too expensive.  
**B.** The proposal was accepted because it was cheap.  
**C.** The proposal was rejected even though it was affordable.  
**D.** The proposal was delayed until it became more costly.

#### 20.

The new evidence cast doubt on the original verdict.

**A.** The new evidence fully confirmed the original verdict.  
**B.** The original verdict removed all doubt about the evidence.  
**C.** The new evidence made the first verdict seem questionable.  
**D.** The new evidence had nothing to do with the verdict.

## פרק 5 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 21.

Provided that the weather holds, the expedition will set off at dawn.

**A.** As long as the weather stays good, the expedition will leave at sunrise.  
**B.** The expedition will leave at dawn even if the weather turns bad.  
**C.** Bad weather is needed for the expedition to set off.  
**D.** The expedition will set off at night regardless of the weather.

#### 22.

The report understates the scale of the environmental damage.

**A.** The report exaggerates the environmental damage.  
**B.** The report makes the environmental damage seem smaller than it really is.  
**C.** The report describes the damage exactly as it is.  
**D.** The report denies that any environmental damage occurred.

#### 23.

His success owes much to his willingness to take risks.

**A.** His success came from always avoiding any risk.  
**B.** His risk-taking had little to do with his success.  
**C.** A large part of his success comes from his readiness to take chances.  
**D.** He succeeded in spite of his fear of taking risks.

## פרק 6 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 24.

The new design is both attractive \_\_\_\_ practical.

**A.** and  
**B.** but  
**C.** or  
**D.** so

#### 25.

The two approaches differ \_\_\_\_ in their basic assumptions.

**A.** frequently  
**B.** fortunately  
**C.** fundamentally  
**D.** finally

#### 26.

The manager’s decision was \_\_\_\_, taking all viewpoints into account.

**A.** hasty  
**B.** reckless  
**C.** judicious  
**D.** arbitrary

#### 27.

The author \_\_\_\_ the reader to question widely accepted beliefs.

**A.** urges  
**B.** ignores  
**C.** forbids  
**D.** denies

#### 28.

The committee’s ruling created an awkward \_\_\_\_ for future cases.

**A.** preface  
**B.** premise  
**C.** precedent  
**D.** preview

#### 29.

The proposal was rejected as \_\_\_\_, promising in theory, unworkable in fact.

**A.** pragmatic  
**B.** utopian  
**C.** realistic  
**D.** feasible

---

## מפתח תשובות

| שאלה | תשובה | הניסוח הנכון |
|---|---|---|
| 1 | B | although |
| 2 | C | combat |
| 3 | C | compare |
| 4 | A | attentive |
| 5 | B | constrained |
| 6 | D | tendentious |
| 7 | C | address |
| 8 | C | so that |
| 9 | B | consistent |
| 10 | D | distinct |
| 11 | C | substantiated |
| 12 | A | even if |
| 13 | A | Whether language merely describes our thoughts or also helps shape them. |
| 14 | A | They divide colors into different numbers of basic terms. |
| 15 | B | People can see more colors than their language names. |
| 16 | D | When their language provides a ready word for the color. |
| 17 | D | As mixed. |
| 18 | D | No matter what brought it about, the results were serious. |
| 19 | A | The proposal was turned down because it was considered too expensive. |
| 20 | C | The new evidence made the first verdict seem questionable. |
| 21 | A | As long as the weather stays good, the expedition will leave at sunrise. |
| 22 | B | The report makes the environmental damage seem smaller than it really is. |
| 23 | C | A large part of his success comes from his readiness to take chances. |
| 24 | A | and |
| 25 | C | fundamentally |
| 26 | C | judicious |
| 27 | A | urges |
| 28 | C | precedent |
| 29 | B | utopian |

## הסברים

**1.** Although = אם כי. ניגוד בין התוצאות המבטיחות לצורך בבדיקות נוספות.

**2.** Combat = להילחם ב. חוקים חדשים נועדו להילחם בזיהום.

**3.** Compare = להשוות. המורה ביקש להשוות בין שני השירים.

**4.** Attentive = קשוב. טקסט צפוף דורש קריאה קשובה.

**5.** Constrained = מוגבל/מרוסן. תקציב וזמן מגבילים את ההתרחבות.

**6.** Tendentious = מגמתי. טשטוש הגבול בין עובדה לדעה מאפיין כתיבה מגמתית.

**7.** Address an issue = לטפל בנושא. הוועדה תטפל בנושא בפגישה הבאה.

**8.** So that = כדי ש. שמרה הערות כדי שלא תשכח את הפרטים.

**9.** Consistent with = עולה בקנה אחד. אם נתנו תמיכה חזקה, התוצאות עקביות עם ההשערה.

**10.** Distinct = נפרדים/שונים. הניגוד "once ... now seen as related" מחייב distinct.

**11.** Substantiate = לבסס/לאשש. ראיות מוצקות מבססות מסקנות.

**12.** Even if = גם אם. מציין ניגוד בין מתודולוגיה טובה למדגם צר.

**13.** הקטע ממחיש שאלה רחבה: האם המילים מתארות את מחשבותינו או גם מעצבות אותן.

**14.** נכתב שחלק מהשפות משתמשות בשניים-שלושה מונחי צבע ואחרות בהבחנות דקות יותר.

**15.** נכתב: "People can usually see and distinguish far more colors than their language names".

**16.** נכתב: "speakers may sort and remember colors slightly faster when their language provides a ready word for them".

**17.** נכתב במפורש: "The evidence is mixed".

**18.** "Whatever the cause ... severe" = יהא הגורם אשר יהא, התוצאות חמורות. התשובה הנכונה שומרת על "no matter what brought it about, the results were serious".

**19.** "on the grounds that it was too costly" = מהנימוק שהיא יקרה מדי. התשובה הנכונה שומרת על "turned down because it was considered too expensive".

**20.** "cast doubt on" = הטיל ספק. התשובה הנכונה שומרת על "made the first verdict seem questionable".

**21.** "Provided that the weather holds" = בתנאי שמזג האוויר יחזיק. התשובה הנכונה שומרת על "as long as the weather stays good ... at sunrise".

**22.** Understate = להמעיט בתיאור. התשובה הנכונה שומרת על "makes the damage seem smaller than it really is".

**23.** "owes much to his willingness to take risks" = חלק נכבד מהצלחתו בזכות נכונותו להסתכן. התשובה הנכונה שומרת על "a large part ... comes from his readiness to take chances".

**24.** Both ... and = גם וגם. העיצוב גם מושך וגם מעשי.

**25.** Fundamentally = ביסודו. הגישות נבדלות באופן יסודי בהנחות.

**26.** Judicious = נבון/שקול. התחשבות בכל נקודות המבט מאפיינת החלטה שקולה.

**27.** Urge = לדרבן/להפציר. הסופר מדרבן את הקורא לפקפק באמונות מקובלות.

**28.** Precedent = תקדים. פסיקה שמשפיעה על מקרים עתידיים יוצרת תקדים.

**29.** Utopian = אוטופי. "promising in theory, unworkable in fact" מגדיר רעיון אוטופי.
