# סימולציה 2 — קל עד בינוני

סימולציה בשישה פרקי הליבה של האמירנט — השלמת משפטים, הבנת הנקרא וניסוח מחדש — ברמה קלה עד בינונית, מתאימה לתחילת התרגול.

**רמה:** קל  
**שאלות במאגר:** 29  
**מוגשות בסימולציה:** 23  
**זמן:** 39 דקות  
**מקור:** https://amirnetwords.com/tests/test-02/play

> הסימולציה מגישה 23 שאלות מתוך מאגר של 29, ובוחרת אותן באופן מסתגל. כאן מופיע המאגר המלא.

---

## פרק 1 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 1.

The museum is free, so it \_\_\_\_ a lot of visitors every day.

**A.** attracts  
**B.** repairs  
**C.** removes  
**D.** refuses

#### 2.

Remember to \_\_\_\_ the lights when you leave the room.

**A.** blow up  
**B.** give in  
**C.** look after  
**D.** switch off

#### 3.

The recipe is simple and easy to \_\_\_\_ at home.

**A.** destroy  
**B.** prepare  
**C.** forbid  
**D.** announce

#### 4.

The film was boring, \_\_\_\_ we left before it ended.

**A.** so  
**B.** but  
**C.** because  
**D.** unless

#### 5.

We arrived late \_\_\_\_ the train was delayed.

**A.** because  
**B.** so  
**C.** but  
**D.** and

#### 6.

The two theories are different in method \_\_\_\_ similar in their goals.

**A.** hence  
**B.** yet  
**C.** thus  
**D.** therefore

## פרק 2 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 7.

You should \_\_\_\_ a coat; it is very cold outside.

**A.** wear  
**B.** cook  
**C.** drive  
**D.** spell

#### 8.

The bridge was old and dangerous, \_\_\_\_ they closed it.

**A.** but  
**B.** although  
**C.** while  
**D.** so

#### 9.

My phone battery is low, \_\_\_\_ I need to charge it soon.

**A.** but  
**B.** so  
**C.** because  
**D.** although

#### 10.

He is a careful driver and rarely \_\_\_\_ accidents.

**A.** causes  
**B.** celebrates  
**C.** collects  
**D.** cancels

#### 11.

She was reluctant to speak, \_\_\_\_ she had a lot to say.

**A.** even though  
**B.** so that  
**C.** as long as  
**D.** in case

#### 12.

Scientists try to \_\_\_\_ their results before publishing them.

**A.** vanish  
**B.** verify  
**C.** violate  
**D.** vary

## פרק 3 — הבנת הנקרא

*5 שאלות בסימולציה · 5 במאגר · 15 דקות*

קראו את הקטע האקדמי הקצר ולאחר מכן ענו על השאלות הנוגעות אליו. כל התשובות מתבססות על המידע שבטקסט בלבד.

### קטע הקריאה: Reading on Paper or on Screen

> Today, students can read their books either on paper or on a screen. Both choices have their advantages. Paper books are easy on the eyes and do not need electricity, so they can be read anywhere. Screens, on the other hand, can hold hundreds of books in one small device and let readers change the size of the letters. Some studies suggest that people remember information better when they read it on paper, especially for difficult subjects. However, screens are very useful for quick reading and for searching inside a text. Many teachers now tell their students to use both. For careful study, they suggest paper, and for fast reading or research, they suggest a screen. In this way, students can enjoy the benefits of each.

#### 13.

What is the passage mainly about?

**A.** Why screens are always better than paper.  
**B.** How to build a reading device.  
**C.** Why students should stop reading books.  
**D.** The advantages of reading on paper and on screens.

#### 14.

According to the passage, one advantage of paper books is that they:

**A.** can hold hundreds of books.  
**B.** let readers change the letter size.  
**C.** are useful for searching inside a text.  
**D.** do not need electricity.

#### 15.

What is one advantage of screens mentioned in the passage?

**A.** They can store many books in one small device.  
**B.** They are easier on the eyes than paper.  
**C.** They never need electricity.  
**D.** They help people forget information.

#### 16.

What do some studies suggest about reading on paper?

**A.** People read much faster on paper.  
**B.** Paper is always cheaper than screens.  
**C.** People may remember difficult information better.  
**D.** Paper books are harder to carry.

#### 17.

For fast reading and research, the passage suggests using:

**A.** only paper books.  
**B.** no books at all.  
**C.** a screen.  
**D.** a printed newspaper.

## פרק 4 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 18.

Most of the students agreed with the new schedule.

**A.** All of the students rejected the new schedule.  
**B.** Only a few students liked the new schedule.  
**C.** The majority of the students supported the new schedule.  
**D.** None of the students cared about the schedule.

#### 19.

The bus was late, so we missed the beginning of the movie.

**A.** We arrived early because the bus was on time.  
**B.** We missed the end of the movie, not the beginning.  
**C.** We missed the start of the movie because the bus arrived late.  
**D.** The bus was late, but we still saw the whole movie.

#### 20.

Reading books can help you learn new words.

**A.** Reading books makes you forget words you already know.  
**B.** Only writing books helps you learn new words.  
**C.** You can build your vocabulary by reading books.  
**D.** Books cannot teach you any new words.

## פרק 5 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 21.

She speaks quietly, but everyone listens to her carefully.

**A.** She speaks loudly, so people ignore her.  
**B.** Nobody listens to her because she is too quiet.  
**C.** She listens carefully to everyone around her.  
**D.** Even though her voice is soft, people pay close attention to her.

#### 22.

The hotel offers free breakfast to all of its guests.

**A.** Only some guests get a free breakfast at the hotel.  
**B.** Every guest at the hotel can have breakfast at no extra cost.  
**C.** Guests must pay extra for breakfast at the hotel.  
**D.** The hotel does not serve breakfast at all.

#### 23.

We should leave now if we want to catch the early train.

**A.** We can leave later and still catch the early train.  
**B.** We missed the early train, so there is no need to hurry.  
**C.** We should wait here because the train is late.  
**D.** To catch the early train, we need to go right away.

## פרק 6 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 24.

The two brothers look so \_\_\_\_ that people often confuse them.

**A.** different  
**B.** similar  
**C.** angry  
**D.** distant

#### 25.

She studied hard \_\_\_\_ she wanted to pass the test.

**A.** but  
**B.** so  
**C.** or  
**D.** because

#### 26.

Children should \_\_\_\_ their hands before eating.

**A.** waste  
**B.** wash  
**C.** weigh  
**D.** wonder

#### 27.

The library is quiet, so it is a good place to \_\_\_\_.

**A.** shout  
**B.** dance  
**C.** study  
**D.** cook

#### 28.

The medicine had a strong \_\_\_\_ on the patient within hours.

**A.** effect  
**B.** affect  
**C.** effort  
**D.** event

#### 29.

The bridge was built \_\_\_\_ withstand strong earthquakes.

**A.** for  
**B.** by  
**C.** with  
**D.** to

---

## מפתח תשובות

| שאלה | תשובה | הניסוח הנכון |
|---|---|---|
| 1 | A | attracts |
| 2 | D | switch off |
| 3 | B | prepare |
| 4 | A | so |
| 5 | A | because |
| 6 | B | yet |
| 7 | A | wear |
| 8 | D | so |
| 9 | B | so |
| 10 | A | causes |
| 11 | A | even though |
| 12 | B | verify |
| 13 | D | The advantages of reading on paper and on screens. |
| 14 | D | do not need electricity. |
| 15 | A | They can store many books in one small device. |
| 16 | C | People may remember difficult information better. |
| 17 | C | a screen. |
| 18 | C | The majority of the students supported the new schedule. |
| 19 | C | We missed the start of the movie because the bus arrived late. |
| 20 | C | You can build your vocabulary by reading books. |
| 21 | D | Even though her voice is soft, people pay close attention to her. |
| 22 | B | Every guest at the hotel can have breakfast at no extra cost. |
| 23 | D | To catch the early train, we need to go right away. |
| 24 | B | similar |
| 25 | D | because |
| 26 | B | wash |
| 27 | C | study |
| 28 | A | effect |
| 29 | D | to |

## הסברים

**1.** Attract = למשוך. מוזיאון חינם מושך מבקרים רבים.

**2.** Switch off = לכבות. מכבים אורות כשעוזבים חדר.

**3.** Prepare = להכין. מכינים מתכון בבית; שאר הפעלים אינם מתאימים.

**4.** השעמום הוא הסיבה, היציאה היא התוצאה: so.

**5.** איחור הרכבת הוא הסיבה לאיחור שלנו: because.

**6.** Yet = אך/ובכל זאת. מציין ניגוד בין שיטה שונה למטרות דומות.

**7.** מעיל "לובשים" (wear). הרמז "very cold" תומך בכך.

**8.** הגשר היה מסוכן (סיבה), ולכן סגרו אותו (תוצאה): so.

**9.** סוללה חלשה היא הסיבה; הצורך לטעון הוא התוצאה: so.

**10.** Cause = לגרום. נהג זהיר ממעט לגרום תאונות.

**11.** Even though = למרות ש. ניגוד בין החשש לדבר לבין מה שרצתה לומר.

**12.** Verify = לאמת. מדענים מאמתים תוצאות לפני פרסום.

**13.** הקטע משווה את היתרונות של קריאה על נייר ועל מסך, ולכן זהו הנושא המרכזי.

**14.** נכתב: "Paper books are easy on the eyes and do not need electricity".

**15.** נכתב: "Screens ... can hold hundreds of books in one small device".

**16.** נכתב: "people remember information better when they read it on paper, especially for difficult subjects".

**17.** נכתב: "for fast reading or research, they suggest a screen".

**18.** "Most" = הרוב. "agreed" = תמכו. התשובה הנכונה שומרת על "the majority supported".

**19.** איחור האוטובוס גרם להחמצת ההתחלה. התשובה הנכונה שומרת על הסיבה (bus late) והתוצאה (missed the start).

**20.** קריאה עוזרת ללמוד מילים. התשובה הנכונה שומרת על "build your vocabulary by reading".

**21.** יש ניגוד: קול שקט אך הקשבה רבה. התשובה הנכונה שומרת על "soft voice" ועל "close attention".

**22.** "free breakfast to all guests" = כל אורח מקבל ארוחת בוקר ללא תשלום. התשובה הנכונה שומרת על "every guest" ו-"no extra cost".

**23.** כדי לתפוס את הרכבת המוקדמת צריך לצאת עכשיו. התשובה הנכונה שומרת על "right away".

**24.** אם מבלבלים ביניהם, הם נראים "דומים" (similar). Different הוא ההפך.

**25.** הרצון לעבור את המבחן הוא הסיבה ללמוד קשה, ולכן because.

**26.** ידיים "רוחצים" (wash) לפני אוכל. שאר הפעלים אינם הגיוניים.

**27.** מקום שקט מתאים "ללמוד" (study). שאר הפעלים סותרים את "quiet".

**28.** Effect (שם עצם) = השפעה. לתרופה הייתה השפעה חזקה. Affect הוא פועל.

**29.** to + פועל מציין מטרה: הגשר נבנה כדי לעמוד ברעידות אדמה חזקות.
