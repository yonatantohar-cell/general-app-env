# סימולציה 3 — קל עד בינוני

סימולציה בשישה פרקי הליבה של האמירנט — השלמת משפטים, הבנת הנקרא וניסוח מחדש — ברמה קלה עד בינונית, מתאימה לתחילת התרגול.

**רמה:** קל  
**שאלות במאגר:** 29  
**מוגשות בסימולציה:** 23  
**זמן:** 39 דקות  
**מקור:** https://amirnetwords.com/tests/test-03/play

> הסימולציה מגישה 23 שאלות מתוך מאגר של 29, ובוחרת אותן באופן מסתגל. כאן מופיע המאגר המלא.

---

## פרק 1 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 1.

Please \_\_\_\_ the volume; the music is too loud.

**A.** raise  
**B.** repeat  
**C.** lower  
**D.** rent

#### 2.

It was raining, \_\_\_\_ we took our umbrellas.

**A.** but  
**B.** although  
**C.** so  
**D.** while

#### 3.

Firefighters are trained to \_\_\_\_ in dangerous situations.

**A.** relax  
**B.** respond  
**C.** retire  
**D.** reward

#### 4.

Please be \_\_\_\_ when you carry the glass dishes.

**A.** careless  
**B.** cheerful  
**C.** careful  
**D.** curious

#### 5.

His argument was weak \_\_\_\_ it lacked any real evidence.

**A.** whereas  
**B.** because  
**C.** unless  
**D.** whether

#### 6.

A balanced diet can \_\_\_\_ the risk of many diseases.

**A.** reduce  
**B.** produce  
**C.** introduce  
**D.** reproduce

## פרק 2 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 7.

The students were excited \_\_\_\_ nervous before the trip.

**A.** so  
**B.** because  
**C.** and  
**D.** unless

#### 8.

She wants to \_\_\_\_ money to buy a new bicycle.

**A.** save  
**B.** spill  
**C.** shout  
**D.** sail

#### 9.

My grandmother likes to \_\_\_\_ stories about her childhood.

**A.** throw  
**B.** tell  
**C.** taste  
**D.** travel

#### 10.

He could not sleep \_\_\_\_ he drank too much coffee.

**A.** because  
**B.** so  
**C.** but  
**D.** or

#### 11.

The report highlights a \_\_\_\_ increase in renewable energy use.

**A.** signal  
**B.** signature  
**C.** significant  
**D.** silent

#### 12.

The author uses simple words \_\_\_\_ readers can understand easily.

**A.** as if  
**B.** so that  
**C.** even if  
**D.** rather than

## פרק 3 — הבנת הנקרא

*5 שאלות בסימולציה · 5 במאגר · 15 דקות*

קראו את הקטע האקדמי הקצר ולאחר מכן ענו על השאלות הנוגעות אליו. כל התשובות מתבססות על המידע שבטקסט בלבד.

### קטע הקריאה: The First Public Parks

> Long ago, most gardens belonged to kings and rich families, and ordinary people were not allowed to enter them. As cities grew larger and more crowded, leaders began to worry about the health of city workers. They noticed that people who lived far from green spaces were often tired and sick. To solve this problem, some cities opened the first public parks, which anyone could visit for free. These parks gave families a place to rest, walk, and breathe fresh air. Children could play outside safely, away from busy streets. Over time, public parks became a normal part of city life. Today, almost every large city has parks, and many people see them as one of the most valuable parts of their neighborhood.

#### 13.

What is the main idea of the passage?

**A.** Why kings built large private gardens.  
**B.** How children learn to play sports.  
**C.** Why cities stopped growing.  
**D.** How and why the first public parks were created.

#### 14.

In the past, who was usually allowed to use gardens?

**A.** Kings and rich families.  
**B.** All city workers.  
**C.** Only children.  
**D.** Visitors from other cities.

#### 15.

Why did leaders begin to worry as cities grew?

**A.** There were too many gardens in the city.  
**B.** Kings wanted larger private gardens.  
**C.** People far from green spaces were often tired and sick.  
**D.** Children refused to play indoors.

#### 16.

What was special about the first public parks?

**A.** Only rich families could enter them.  
**B.** They were built inside palaces.  
**C.** Anyone could visit them for free.  
**D.** They charged a high entrance fee.

#### 17.

According to the passage, parks gave families a place to:

**A.** buy and sell goods.  
**B.** rest, walk, and breathe fresh air.  
**C.** build new houses.  
**D.** study for exams.

## פרק 4 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 18.

The teacher explained the lesson clearly, so we understood it.

**A.** We understood the lesson because the teacher explained it well.  
**B.** We did not understand the lesson even though it was clear.  
**C.** The teacher confused us by explaining the lesson badly.  
**D.** The teacher explained the lesson, but we still understood nothing.

#### 19.

He saved enough money to buy a new computer.

**A.** He put aside enough money to purchase a new computer.  
**B.** He spent all his money and could not buy a computer.  
**C.** He borrowed a computer because he had no money.  
**D.** He still needs more money to buy a computer.

#### 20.

Unless it rains, the picnic will take place in the park.

**A.** The picnic will be in the park only if it rains.  
**B.** The picnic will be held in the park as long as it does not rain.  
**C.** The picnic is cancelled no matter what the weather is.  
**D.** It will rain, so the picnic will move to the park.

## פרק 5 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 21.

The new phone is cheaper than the old one.

**A.** The old phone costs more than the new one.  
**B.** The new phone costs more than the old one.  
**C.** Both phones cost exactly the same.  
**D.** The old phone is the cheapest of the two.

#### 22.

They worked together to finish the project on time.

**A.** They worked alone and missed the deadline.  
**B.** By cooperating, they completed the project before the deadline.  
**C.** They finished the project late despite working together.  
**D.** They started the project but never finished it.

#### 23.

The doctor advised him to rest for a few days.

**A.** The doctor told him to keep working without any rest.  
**B.** The doctor forced him to rest for several weeks.  
**C.** The doctor recommended that he take a few days of rest.  
**D.** The doctor said he did not need any rest at all.

## פרק 6 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 24.

A good map can \_\_\_\_ you find the way easily.

**A.** help  
**B.** hurt  
**C.** hide  
**D.** hire

#### 25.

The cake tastes great \_\_\_\_ it looks a little burnt.

**A.** because  
**B.** so  
**C.** and  
**D.** although

#### 26.

The road was blocked, \_\_\_\_ we found another route.

**A.** so  
**B.** but  
**C.** because  
**D.** although

#### 27.

The new park is large enough to \_\_\_\_ many families.

**A.** hide  
**B.** heat  
**C.** hold  
**D.** hunt

#### 28.

The lecture was informative, \_\_\_\_ rather difficult to follow.

**A.** therefore  
**B.** hence  
**C.** though  
**D.** thus

#### 29.

The manager decided to \_\_\_\_ the meeting until next week.

**A.** postpone  
**B.** propose  
**C.** promote  
**D.** protect

---

## מפתח תשובות

| שאלה | תשובה | הניסוח הנכון |
|---|---|---|
| 1 | C | lower |
| 2 | C | so |
| 3 | B | respond |
| 4 | C | careful |
| 5 | B | because |
| 6 | A | reduce |
| 7 | C | and |
| 8 | A | save |
| 9 | B | tell |
| 10 | A | because |
| 11 | C | significant |
| 12 | B | so that |
| 13 | D | How and why the first public parks were created. |
| 14 | A | Kings and rich families. |
| 15 | C | People far from green spaces were often tired and sick. |
| 16 | C | Anyone could visit them for free. |
| 17 | B | rest, walk, and breathe fresh air. |
| 18 | A | We understood the lesson because the teacher explained it well. |
| 19 | A | He put aside enough money to purchase a new computer. |
| 20 | B | The picnic will be held in the park as long as it does not rain. |
| 21 | A | The old phone costs more than the new one. |
| 22 | B | By cooperating, they completed the project before the deadline. |
| 23 | C | The doctor recommended that he take a few days of rest. |
| 24 | A | help |
| 25 | D | although |
| 26 | A | so |
| 27 | C | hold |
| 28 | C | though |
| 29 | A | postpone |

## הסברים

**1.** אם המוזיקה רועשת מדי, צריך "להנמיך" (lower). Raise הוא ההפך.

**2.** הגשם הוא הסיבה; לקיחת המטריות היא התוצאה: so.

**3.** Respond = להגיב. כבאים מאומנים להגיב במצבי סכנה.

**4.** עם כלי זכוכית צריך להיות "זהיר" (careful). Careless הוא ההפך.

**5.** היעדר הראיות הוא הסיבה לחולשת הטיעון: because.

**6.** Reduce = להפחית. תזונה מאוזנת מפחיתה סיכון למחלות.

**7.** שתי תחושות מתקיימות יחד, ולכן מחברים אותן ב-and.

**8.** Save = לחסוך. חוסכים כסף כדי לקנות משהו.

**9.** סיפורים "מספרים" (tell). שאר הפעלים אינם מתאימים ל-stories.

**10.** הקפה הוא הסיבה לכך שלא הצליח לישון: because.

**11.** Significant = משמעותי. הדו"ח מצביע על עלייה משמעותית.

**12.** So that = כדי ש. הסופר משתמש במילים פשוטות כדי שהקוראים יבינו.

**13.** הקטע מסביר כיצד ומדוע נוצרו הפארקים הציבוריים הראשונים.

**14.** נכתב: "most gardens belonged to kings and rich families, and ordinary people were not allowed to enter them".

**15.** נכתב: "people who lived far from green spaces were often tired and sick".

**16.** נכתב: "the first public parks, which anyone could visit for free".

**17.** נכתב: "These parks gave families a place to rest, walk, and breathe fresh air".

**18.** הסבר ברור הוביל להבנה. התשובה הנכונה שומרת על הסיבה (explained well) והתוצאה (understood).

**19.** "saved enough" = חסך מספיק. התשובה הנכונה שומרת על "put aside enough money to purchase".

**20.** "Unless it rains" = אם לא ירד גשם. התשובה הנכונה שומרת על "as long as it does not rain".

**21.** אם החדש זול יותר, הישן יקר יותר. התשובה הנכונה הופכת את ההשוואה בלי לשנות את המשמעות.

**22.** עבודה משותפת הובילה לסיום בזמן. התשובה הנכונה שומרת על "cooperating" ועל "before the deadline".

**23.** Advise = להמליץ. התשובה הנכונה שומרת על "recommended a few days of rest".

**24.** Help = לעזור. מפה טובה עוזרת למצוא את הדרך.

**25.** יש ניגוד בין הטעם הטוב למראה השרוף, ולכן although.

**26.** חסימת הדרך היא הסיבה; מציאת מסלול אחר היא התוצאה: so.

**27.** Hold כאן = להכיל. הפארק גדול מספיק להכיל משפחות רבות.

**28.** Though = אם כי. ניגוד בין מועילות ההרצאה לבין הקושי לעקוב.

**29.** Postpone = לדחות. המנהל דחה את הפגישה לשבוע הבא.
