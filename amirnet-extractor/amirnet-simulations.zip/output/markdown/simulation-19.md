# סימולציה 19 — קשה

סימולציה מאתגרת בשישה פרקי הליבה של האמירנט, ברמה גבוהה ומיועדת למי שמכוון לציון גבוה.

**רמה:** expert  
**שאלות במאגר:** 29  
**מוגשות בסימולציה:** 23  
**זמן:** 39 דקות  
**מקור:** https://amirnetwords.com/tests/test-19/play

> הסימולציה מגישה 23 שאלות מתוך מאגר של 29, ובוחרת אותן באופן מסתגל. כאן מופיע המאגר המלא.

---

## פרק 1 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 1.

The findings were \_\_\_\_ across different countries and cultures.

**A.** reduced  
**B.** released  
**C.** replicated  
**D.** relocated

#### 2.

The plan looked promising but \_\_\_\_ under closer scrutiny.

**A.** flourished  
**B.** thrived  
**C.** collapsed  
**D.** prevailed

#### 3.

The institution has a \_\_\_\_ reputation built over many decades.

**A.** dubious  
**B.** distinguished  
**C.** damaged  
**D.** doubtful

#### 4.

The study’s conclusions are \_\_\_\_ to the assumptions built into its model.

**A.** immune  
**B.** indifferent  
**C.** oblivious  
**D.** sensitive

#### 5.

The text \_\_\_\_ a tension that the author never fully resolves.

**A.** evades  
**B.** embodies  
**C.** erases  
**D.** excludes

#### 6.

The lecture was \_\_\_\_ with insight, repaying the listener’s full attention.

**A.** devoid  
**B.** replete  
**C.** bereft  
**D.** empty

## פרק 2 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 7.

The policy had a \_\_\_\_ effect, helping some while harming others.

**A.** uniform  
**B.** consistent  
**C.** identical  
**D.** mixed

#### 8.

The two factors are \_\_\_\_, making it hard to study them separately.

**A.** intertwined  
**B.** independent  
**C.** isolated  
**D.** unrelated

#### 9.

The author writes with a \_\_\_\_ that few of her peers can match.

**A.** hesitancy  
**B.** awkwardness  
**C.** rigidity  
**D.** fluency

#### 10.

His argument \_\_\_\_ a question that has puzzled scholars for centuries.

**A.** resolves  
**B.** retires  
**C.** refutes  
**D.** revives

#### 11.

The reasoning is \_\_\_\_, drawing a universal rule from a single case.

**A.** understated  
**B.** qualified  
**C.** restrained  
**D.** overgeneralized

#### 12.

The hypothesis is elegant \_\_\_\_ ultimately untestable.

**A.** but  
**B.** so  
**C.** thus  
**D.** hence

## פרק 3 — הבנת הנקרא

*5 שאלות בסימולציה · 5 במאגר · 15 דקות*

קראו את הקטע האקדמי הקצר ולאחר מכן ענו על השאלות הנוגעות אליו. כל התשובות מתבססות על המידע שבטקסט בלבד.

### קטע הקריאה: The Quiet Power of Infrastructure

> $8

#### 13.

What is the main idea of the passage?

**A.** Infrastructure only matters when new projects are built.  
**B.** Infrastructure has no effect on people’s lives.  
**C.** Infrastructure is mostly invisible yet quietly shapes society and opportunity.  
**D.** Visible projects are always more useful than infrastructure.

#### 14.

When does infrastructure tend to attract attention?

**A.** Only when it fails.  
**B.** When it works perfectly.  
**C.** When it is first designed.  
**D.** When no one depends on it.

#### 15.

Why is the invisibility of infrastructure described as a measure of success?

**A.** Well-designed infrastructure works unnoticed in the background.  
**B.** Invisible infrastructure does no work at all.  
**C.** Success requires infrastructure to fail often.  
**D.** People always notice good infrastructure.

#### 16.

What cost does this same invisibility carry?

**A.** Maintaining and renewing infrastructure is easily neglected.  
**B.** Infrastructure becomes too visible to ignore.  
**C.** It makes maintenance unnecessary.  
**D.** It forces too much public attention on pipes.

#### 17.

According to the passage, what do decisions made decades ago continue to shape?

**A.** Who has access to clean water, fast transport, or reliable energy.  
**B.** Which projects look most impressive.  
**C.** How often power cuts are reported.  
**D.** Nothing of lasting importance.

## פרק 4 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 18.

A reluctance to adapt rendered the institution increasingly obsolete.

**A.** The institution’s eagerness to adapt kept it modern.  
**B.** The institution stayed up to date despite refusing to change.  
**C.** Because it was unwilling to change, the institution grew more and more outdated.  
**D.** Adapting quickly made the institution obsolete.

#### 19.

The argument is persuasive insofar as it rests on verifiable facts.

**A.** The argument convinces no matter how false its facts are.  
**B.** The argument convinces to the degree that it is based on facts that can be checked.  
**C.** The argument is weak precisely because it relies on facts.  
**D.** The argument avoids any facts that could be verified.

#### 20.

The committee deferred the decision pending further consultation.

**A.** The committee made the decision before any consultation.  
**B.** The committee cancelled the decision and ended all consultation.  
**C.** The committee put off the decision until more advice could be gathered.  
**D.** The committee decided quickly to avoid further consultation.

## פרק 5 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 21.

The theory accounts for the phenomenon more convincingly than its rivals do.

**A.** The rival theories explain the phenomenon more convincingly.  
**B.** The theory explains the phenomenon exactly as well as its rivals.  
**C.** The theory fails to explain the phenomenon at all.  
**D.** The theory explains the phenomenon in a more believable way than the competing theories.

#### 22.

Implicit in his proposal is the assumption that growth is always desirable.

**A.** His proposal openly argues that growth is undesirable.  
**B.** His proposal makes no assumption about growth at all.  
**C.** His proposal quietly takes for granted that growth is always something good.  
**D.** His proposal states clearly that growth is sometimes harmful.

#### 23.

The verdict hinged less on the facts than on how they were presented.

**A.** The facts mattered far more to the verdict than their presentation.  
**B.** Neither the facts nor their presentation affected the verdict.  
**C.** The verdict depended only on the raw facts.  
**D.** The way the facts were presented mattered more to the verdict than the facts themselves.

## פרק 6 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 24.

The book \_\_\_\_ a complex theory into accessible language.

**A.** transforms  
**B.** transfers  
**C.** translates  
**D.** transmits

#### 25.

The argument is sound \_\_\_\_ its premises are accepted.

**A.** although  
**B.** whereas  
**C.** provided  
**D.** despite

#### 26.

The policy \_\_\_\_ the very inequality it claimed to address.

**A.** entrenched  
**B.** eradicated  
**C.** erased  
**D.** eliminated

#### 27.

The reform’s benefits are \_\_\_\_, while its costs are immediate.

**A.** long-term  
**B.** instant  
**C.** short-lived  
**D.** momentary

#### 28.

The two findings \_\_\_\_ rather than reinforce one another.

**A.** amplify  
**B.** echo  
**C.** offset  
**D.** mirror

#### 29.

The author’s tone is \_\_\_\_, treating grand claims with quiet irony.

**A.** bombastic  
**B.** understated  
**C.** grandiose  
**D.** flamboyant

---

## מפתח תשובות

| שאלה | תשובה | הניסוח הנכון |
|---|---|---|
| 1 | C | replicated |
| 2 | C | collapsed |
| 3 | B | distinguished |
| 4 | D | sensitive |
| 5 | B | embodies |
| 6 | B | replete |
| 7 | D | mixed |
| 8 | A | intertwined |
| 9 | D | fluency |
| 10 | D | revives |
| 11 | D | overgeneralized |
| 12 | A | but |
| 13 | C | Infrastructure is mostly invisible yet quietly shapes society and opportunity. |
| 14 | A | Only when it fails. |
| 15 | A | Well-designed infrastructure works unnoticed in the background. |
| 16 | A | Maintaining and renewing infrastructure is easily neglected. |
| 17 | A | Who has access to clean water, fast transport, or reliable energy. |
| 18 | C | Because it was unwilling to change, the institution grew more and more outdated. |
| 19 | B | The argument convinces to the degree that it is based on facts that can be checked. |
| 20 | C | The committee put off the decision until more advice could be gathered. |
| 21 | D | The theory explains the phenomenon in a more believable way than the competing theories. |
| 22 | C | His proposal quietly takes for granted that growth is always something good. |
| 23 | D | The way the facts were presented mattered more to the verdict than the facts themselves. |
| 24 | C | translates |
| 25 | C | provided |
| 26 | A | entrenched |
| 27 | A | long-term |
| 28 | C | offset |
| 29 | B | understated |

## הסברים

**1.** Replicate = לשחזר. הממצאים שוחזרו במדינות ובתרבויות שונות.

**2.** Collapse = להתמוטט. "promising but ... under scrutiny" מחייב פועל המציין כישלון.

**3.** Distinguished = נכבד/מכובד. מוניטין שנבנה לאורך עשורים הוא מכובד.

**4.** Sensitive to = רגיש ל. המסקנות רגישות להנחות שבבסיס המודל.

**5.** Embody = לגלם/להכיל בתוכו. הטקסט מגלם מתח שאינו נפתר.

**6.** Replete with = רווי/מלא ב. הרצאה רוויה בתובנות מתגמלת קשב מלא.

**7.** Mixed = מעורב. עזרה לחלק ופגיעה באחרים מצביעה על השפעה מעורבת.

**8.** Intertwined = שזורים זה בזה. אם קשה להפרידם, הם שזורים.

**9.** Fluency = שטף. כתיבה שמעטים משתווים לה מצטיינת בשטף.

**10.** Revive = להחיות/לעורר מחדש. הטיעון מעורר מחדש שאלה עתיקה.

**11.** Overgeneralized = מוכלל יתר על המידה. גזירת כלל אוניברסלי ממקרה יחיד היא הכללת יתר.

**12.** יש ניגוד בין האלגנטיות לבין חוסר היכולת לבחון, ולכן but.

**13.** הרעיון המרכזי: התשתית בלתי נראית ברובה אך מעצבת בשקט את החברה ואת ההזדמנויות.

**14.** נכתב: "Infrastructure ... tends to attract attention only when it fails".

**15.** נכתב: "well-designed infrastructure recedes into the background, doing its work unnoticed".

**16.** נכתב: "the slow work of maintaining and renewing it is easily neglected in favor of more visible projects".

**17.** נכתב: "Decisions made decades ago continue to shape who has access to clean water, fast transport, or reliable energy".

**18.** "reluctance to adapt rendered ... obsolete" = חוסר הנכונות להשתנות הפך אותו למיושן. התשובה הנכונה שומרת על הסיבה (unwilling to change) והתוצאה (more and more outdated).

**19.** "persuasive insofar as it rests on verifiable facts" = משכנע במידה שהוא נשען על עובדות הניתנות לאימות. התשובה הנכונה שומרת על התנאי הזה.

**20.** "deferred the decision pending further consultation" = דחתה את ההחלטה עד להתייעצות נוספת. התשובה הנכונה שומרת על "put off the decision until more advice could be gathered".

**21.** "accounts for the phenomenon more convincingly than its rivals" = מסביר את התופעה בצורה משכנעת יותר מהמתחרות. התשובה הנכונה שומרת על ההשוואה והכיוון.

**22.** "Implicit ... the assumption that growth is always desirable" = גלומה בהצעתו ההנחה שהצמיחה תמיד רצויה. התשובה הנכונה שומרת על "quietly takes for granted that growth is always something good".

**23.** "hinged less on the facts than on how they were presented" = הוכרע פחות בזכות העובדות ויותר בזכות אופן הצגתן. התשובה הנכונה שומרת על סדר העדיפות הזה.

**24.** Translate (into) = להמיר/לתרגם. הספר הופך תאוריה מורכבת לשפה נגישה.

**25.** Provided (that) = בתנאי ש. הטיעון תקף בתנאי שמקבלים את הנחותיו.

**26.** Entrench = להשריש/לבסס. אירוניה: המדיניות השרישה את אי-השוויון שטענה למגר.

**27.** Long-term = ארוכי טווח. הניגוד מול "immediate costs" מחייב הטבות ארוכות טווח.

**28.** Offset = לקזז/לאזן. "rather than reinforce" מחייב פועל מנוגד לחיזוק.

**29.** Understated = מאופק. אירוניה שקטה כלפי טענות גדולות מאפיינת טון מאופק.
