# סימולציה 7 — בינוני

סימולציה בשישה פרקי הליבה של האמירנט ברמה בינונית, המשלבת אוצר מילים אקדמי ומבני משפט מורכבים יותר.

**רמה:** בינוני  
**שאלות במאגר:** 29  
**מוגשות בסימולציה:** 23  
**זמן:** 39 דקות  
**מקור:** https://amirnetwords.com/tests/test-07/play

> הסימולציה מגישה 23 שאלות מתוך מאגר של 29, ובוחרת אותן באופן מסתגל. כאן מופיע המאגר המלא.

---

## פרק 1 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 1.

He could not find his glasses, so he \_\_\_\_ everywhere.

**A.** shouted  
**B.** smiled  
**C.** slept  
**D.** searched

#### 2.

The movie starts at eight, so do not \_\_\_\_ late.

**A.** argue  
**B.** admire  
**C.** arrange  
**D.** arrive

#### 3.

I will call you \_\_\_\_ I get home tonight.

**A.** so  
**B.** because  
**C.** when  
**D.** but

#### 4.

The plan was rejected \_\_\_\_ it was too expensive.

**A.** in spite of  
**B.** as well as  
**C.** on the grounds that  
**D.** in order that

#### 5.

The teacher asked us to \_\_\_\_ the main idea of the text.

**A.** summarize  
**B.** symbolize  
**C.** sympathize  
**D.** specialize

#### 6.

Her explanation was so \_\_\_\_ that it left the audience more confused than before.

**A.** concise  
**B.** coherent  
**C.** clear  
**D.** convoluted

## פרק 2 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 7.

The instructions say to mix the flour \_\_\_\_ the sugar.

**A.** from  
**B.** with  
**C.** since  
**D.** until

#### 8.

The baby was crying, \_\_\_\_ his mother picked him up.

**A.** but  
**B.** so  
**C.** because  
**D.** although

#### 9.

The shirt was too small, so she \_\_\_\_ it for a larger one.

**A.** explained  
**B.** expected  
**C.** exchanged  
**D.** exploded

#### 10.

The witness gave a \_\_\_\_ account of what happened.

**A.** delayed  
**B.** doubtful  
**C.** distant  
**D.** detailed

#### 11.

The price of housing has risen \_\_\_\_ over the past decade.

**A.** suddenly  
**B.** rarely  
**C.** steadily  
**D.** barely

#### 12.

The committee remained \_\_\_\_ despite mounting pressure to change its decision.

**A.** adamant  
**B.** flexible  
**C.** hesitant  
**D.** indifferent

## פרק 3 — הבנת הנקרא

*5 שאלות בסימולציה · 5 במאגר · 15 דקות*

קראו את הקטע האקדמי הקצר ולאחר מכן ענו על השאלות הנוגעות אליו. כל התשובות מתבססות על המידע שבטקסט בלבד.

### קטע הקריאה: The Limits of Multitasking

> Many people believe they can do several demanding tasks at once, such as writing an essay while replying to messages. Psychologists, however, have found that the human brain does not truly perform two difficult tasks at the same time. Instead, it switches rapidly between them. Each switch takes a small amount of time and mental effort, and these costs add up. As a result, people who try to multitask often work more slowly and make more mistakes than those who focus on one task at a time. The feeling of being productive can be misleading, because constant switching keeps the mind busy without improving the quality of the work. Researchers suggest that grouping similar tasks together and limiting interruptions can lead to better results. Far from being a sign of a sharp mind, heavy multitasking may actually reduce both speed and accuracy.

#### 13.

What is the main point of the passage?

**A.** The brain easily handles many hard tasks at once.  
**B.** Replying to messages is the most important task.  
**C.** People should never work on essays.  
**D.** Multitasking usually lowers speed and accuracy rather than raising them.

#### 14.

According to psychologists, what does the brain actually do during "multitasking"?

**A.** It switches rapidly between tasks.  
**B.** It performs two hard tasks at exactly the same time.  
**C.** It stops working on both tasks.  
**D.** It remembers tasks but does not do them.

#### 15.

Why do the costs of switching matter?

**A.** Switching makes tasks easier each time.  
**B.** Each switch takes time and effort, and these costs add up.  
**C.** Switching uses no mental effort at all.  
**D.** Switching only affects very simple tasks.

#### 16.

Why can the feeling of being productive be misleading?

**A.** Constant switching keeps the mind busy without improving the work.  
**B.** Productivity always means high-quality work.  
**C.** The mind is never busy while multitasking.  
**D.** Switching always improves the quality of work.

#### 17.

What do researchers suggest for better results?

**A.** Add as many interruptions as possible.  
**B.** Group similar tasks together and limit interruptions.  
**C.** Always work on the hardest tasks together.  
**D.** Avoid finishing any task completely.

## פרק 4 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 18.

The author argues that technology has changed how we read.

**A.** The author denies that technology has affected our reading.  
**B.** The writer says reading has stayed exactly the same.  
**C.** The author argues that reading has changed technology.  
**D.** The writer claims that technology has altered our reading habits.

#### 19.

Whereas city life is fast, life in the village is calm.

**A.** City life moves quickly, while village life is peaceful.  
**B.** Both city life and village life are equally fast.  
**C.** Village life is fast, but city life is calm.  
**D.** City life and village life are both very calm.

#### 20.

The manager praised the team for completing the task early.

**A.** The manager criticized the team for finishing the task late.  
**B.** The manager ignored the team even though they finished early.  
**C.** The manager praised the team for starting the task early.  
**D.** The manager complimented the team because they finished the task ahead of time.

## פרק 5 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 21.

Without enough sleep, students find it hard to focus.

**A.** A lack of sleep makes it difficult for students to concentrate.  
**B.** Students focus better when they sleep less.  
**C.** Enough sleep makes it hard for students to focus.  
**D.** Sleep has no effect on how well students focus.

#### 22.

The company expanded into new markets to increase its profits.

**A.** In order to earn more money, the company entered new markets.  
**B.** The company left several markets to reduce its profits.  
**C.** The company increased its profits by closing old markets.  
**D.** The company entered new markets but earned no profit.

#### 23.

The bridge collapsed because it had not been repaired for years.

**A.** The bridge collapsed right after it was repaired.  
**B.** The bridge stood firm despite years without repairs.  
**C.** The bridge was repaired often, yet it collapsed.  
**D.** Years without repairs caused the bridge to fall.

## פרק 6 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 24.

She is allergic to nuts, \_\_\_\_ she avoids them completely.

**A.** so  
**B.** but  
**C.** although  
**D.** or

#### 25.

A good teacher tries to \_\_\_\_ every student to learn.

**A.** endanger  
**B.** embarrass  
**C.** encourage  
**D.** enlarge

#### 26.

The article provides a \_\_\_\_ overview of recent research.

**A.** thoughtless  
**B.** thankful  
**C.** thorough  
**D.** thrilling

#### 27.

The economy is growing, \_\_\_\_ unemployment remains high.

**A.** so  
**B.** thus  
**C.** yet  
**D.** hence

#### 28.

You can borrow the book \_\_\_\_ you return it within a week.

**A.** as long as  
**B.** in spite of  
**C.** so far  
**D.** as well as

#### 29.

The new evidence served to \_\_\_\_ rather than confirm the earlier theory.

**A.** reinforce  
**B.** undermine  
**C.** support  
**D.** strengthen

---

## מפתח תשובות

| שאלה | תשובה | הניסוח הנכון |
|---|---|---|
| 1 | D | searched |
| 2 | D | arrive |
| 3 | C | when |
| 4 | C | on the grounds that |
| 5 | A | summarize |
| 6 | D | convoluted |
| 7 | B | with |
| 8 | B | so |
| 9 | C | exchanged |
| 10 | D | detailed |
| 11 | C | steadily |
| 12 | A | adamant |
| 13 | D | Multitasking usually lowers speed and accuracy rather than raising them. |
| 14 | A | It switches rapidly between tasks. |
| 15 | B | Each switch takes time and effort, and these costs add up. |
| 16 | A | Constant switching keeps the mind busy without improving the work. |
| 17 | B | Group similar tasks together and limit interruptions. |
| 18 | D | The writer claims that technology has altered our reading habits. |
| 19 | A | City life moves quickly, while village life is peaceful. |
| 20 | D | The manager complimented the team because they finished the task ahead of time. |
| 21 | A | A lack of sleep makes it difficult for students to concentrate. |
| 22 | A | In order to earn more money, the company entered new markets. |
| 23 | D | Years without repairs caused the bridge to fall. |
| 24 | A | so |
| 25 | C | encourage |
| 26 | C | thorough |
| 27 | C | yet |
| 28 | A | as long as |
| 29 | B | undermine |

## הסברים

**1.** Search = לחפש. כשלא מצא את המשקפיים, חיפש בכל מקום.

**2.** Arrive = להגיע. הרמז "late" תומך בכך.

**3.** When = כאשר. אתקשר כאשר אגיע הביתה.

**4.** On the grounds that = בנימוק ש. התוכנית נדחתה בנימוק שהיא יקרה.

**5.** Summarize = לסכם. המורה ביקש לסכם את הרעיון המרכזי.

**6.** Convoluted = מסובך/מפותל. אם הקהל התבלבל יותר, ההסבר היה מפותל.

**7.** Mix with = לערבב עם. מערבבים קמח עם סוכר.

**8.** הבכי הוא הסיבה; הרמת התינוק היא התוצאה: so.

**9.** Exchange = להחליף. החליפה את החולצה הקטנה בגדולה יותר.

**10.** Detailed = מפורט. העד מסר תיאור מפורט של האירוע.

**11.** Steadily = בהתמדה. "over the past decade" מתאים לעלייה הדרגתית ומתמשכת.

**12.** Adamant = נחוש/בלתי מתפשר. הניגוד עם הלחץ לשנות מחייב נחישות.

**13.** הרעיון המרכזי: ריבוי משימות בדרך כלל מפחית מהירות ודיוק במקום לשפר אותם.

**14.** נכתב: "Instead, it switches rapidly between them".

**15.** נכתב: "Each switch takes a small amount of time and mental effort, and these costs add up".

**16.** נכתב: "constant switching keeps the mind busy without improving the quality of the work".

**17.** נכתב: "grouping similar tasks together and limiting interruptions can lead to better results".

**18.** Argue = לטעון; altered = שינתה. התשובה הנכונה שומרת על "technology has altered our reading habits" עם הכיוון הנכון.

**19.** "Whereas" יוצר ניגוד בין העיר לכפר. התשובה הנכונה שומרת על "city ... quickly, while village ... peaceful".

**20.** Praise = לשבח; ahead of time = מוקדם מהזמן. התשובה הנכונה שומרת על "complimented ... finished the task ahead of time".

**21.** מחסור בשינה מקשה על ריכוז. התשובה הנכונה שומרת על "a lack of sleep makes it difficult ... to concentrate".

**22.** הכניסה לשווקים חדשים נועדה להגדיל רווחים. התשובה הנכונה שומרת על המטרה "to earn more money".

**23.** היעדר תיקונים הוא הסיבה לקריסה. התשובה הנכונה שומרת על "years without repairs caused the bridge to fall".

**24.** האלרגיה היא הסיבה; ההימנעות היא התוצאה: so.

**25.** Encourage = לעודד. מורה טוב מעודד תלמידים ללמוד.

**26.** Thorough = יסודי/מקיף. המאמר מספק סקירה מקיפה.

**27.** Yet = ובכל זאת. ניגוד בין הצמיחה לבין האבטלה הגבוהה.

**28.** As long as = כל עוד/בתנאי ש. ניתן לשאול את הספר בתנאי שיוחזר בזמן.

**29.** Undermine = לערער. "rather than confirm" מחייב פועל המנוגד לאישוש.
