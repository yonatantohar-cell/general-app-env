# סימולציות אמירנט — amirnetwords

**20** סימולציות · **580** שאלות בסך הכול.

| # | סימולציה | רמה | שאלות | קובץ |
|---|---|---|---|---|
| 1 | סימולציה 1 — קל עד בינוני | קל | 29 | [simulation-01.md](./simulation-01.md) |
| 2 | סימולציה 2 — קל עד בינוני | קל | 29 | [simulation-02.md](./simulation-02.md) |
| 3 | סימולציה 3 — קל עד בינוני | קל | 29 | [simulation-03.md](./simulation-03.md) |
| 4 | סימולציה 4 — קל עד בינוני | קל | 29 | [simulation-04.md](./simulation-04.md) |
| 5 | סימולציה 5 — קל עד בינוני | קל | 29 | [simulation-05.md](./simulation-05.md) |
| 6 | סימולציה 6 — בינוני | בינוני | 29 | [simulation-06.md](./simulation-06.md) |
| 7 | סימולציה 7 — בינוני | בינוני | 29 | [simulation-07.md](./simulation-07.md) |
| 8 | סימולציה 8 — בינוני | בינוני | 29 | [simulation-08.md](./simulation-08.md) |
| 9 | סימולציה 9 — בינוני | בינוני | 29 | [simulation-09.md](./simulation-09.md) |
| 10 | סימולציה 10 — בינוני | בינוני | 29 | [simulation-10.md](./simulation-10.md) |
| 11 | סימולציה 11 — בינוני עד קשה | קשה | 29 | [simulation-11.md](./simulation-11.md) |
| 12 | סימולציה 12 — בינוני עד קשה | קשה | 29 | [simulation-12.md](./simulation-12.md) |
| 13 | סימולציה 13 — בינוני עד קשה | קשה | 29 | [simulation-13.md](./simulation-13.md) |
| 14 | סימולציה 14 — בינוני עד קשה | קשה | 29 | [simulation-14.md](./simulation-14.md) |
| 15 | סימולציה 15 — בינוני עד קשה | קשה | 29 | [simulation-15.md](./simulation-15.md) |
| 16 | סימולציה 16 — קשה | expert | 29 | [simulation-16.md](./simulation-16.md) |
| 17 | סימולציה 17 — קשה | expert | 29 | [simulation-17.md](./simulation-17.md) |
| 18 | סימולציה 18 — קשה | expert | 29 | [simulation-18.md](./simulation-18.md) |
| 19 | סימולציה 19 — קשה | expert | 29 | [simulation-19.md](./simulation-19.md) |
| 20 | סימולציה 20 — קשה | expert | 29 | [simulation-20.md](./simulation-20.md) |
