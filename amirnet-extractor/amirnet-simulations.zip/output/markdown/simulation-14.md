# סימולציה 14 — בינוני עד קשה

סימולציה בשישה פרקי הליבה של האמירנט ברמה בינונית עד קשה, עם ניגוד, סיבה ותוצאה והבחנות דקות.

**רמה:** קשה  
**שאלות במאגר:** 29  
**מוגשות בסימולציה:** 23  
**זמן:** 39 דקות  
**מקור:** https://amirnetwords.com/tests/test-14/play

> הסימולציה מגישה 23 שאלות מתוך מאגר של 29, ובוחרת אותן באופן מסתגל. כאן מופיע המאגר המלא.

---

## פרק 1 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 1.

The shop stays open late \_\_\_\_ serve more customers.

**A.** in case of  
**B.** instead of  
**C.** as long as  
**D.** so as to

#### 2.

The theory remains popular \_\_\_\_ several serious objections.

**A.** despite  
**B.** because of  
**C.** due to  
**D.** thanks to

#### 3.

The disease spreads \_\_\_\_, often before symptoms even appear.

**A.** rapidly  
**B.** reluctantly  
**C.** rarely  
**D.** roughly

#### 4.

The new approach \_\_\_\_ the strengths of both earlier methods.

**A.** conceals  
**B.** contradicts  
**C.** cancels  
**D.** combines

#### 5.

The researchers were \_\_\_\_ in their use of statistical methods.

**A.** rigorous  
**B.** negligent  
**C.** reckless  
**D.** casual

#### 6.

The reforms were \_\_\_\_, dismantling structures built over a century.

**A.** trivial  
**B.** marginal  
**C.** sweeping  
**D.** cosmetic

## פרק 2 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 7.

The scientist \_\_\_\_ the data carefully before drawing conclusions.

**A.** announced  
**B.** analyzed  
**C.** annoyed  
**D.** annexed

#### 8.

The article aims to \_\_\_\_ readers about healthy eating.

**A.** educate  
**B.** estimate  
**C.** eliminate  
**D.** evaluate

#### 9.

The two sides eventually found \_\_\_\_ ground after long discussions.

**A.** hostile  
**B.** separate  
**C.** common  
**D.** distant

#### 10.

His behavior was \_\_\_\_ with his stated values, raising suspicion.

**A.** inconsistent  
**B.** aligned  
**C.** compatible  
**D.** harmonious

#### 11.

The evidence is \_\_\_\_ at best, and should not be treated as decisive.

**A.** conclusive  
**B.** definitive  
**C.** circumstantial  
**D.** irrefutable

#### 12.

Her thesis is provocative \_\_\_\_ not entirely convincing.

**A.** so  
**B.** if  
**C.** because  
**D.** therefore

## פרק 3 — הבנת הנקרא

*5 שאלות בסימולציה · 5 במאגר · 15 דקות*

קראו את הקטע האקדמי הקצר ולאחר מכן ענו על השאלות הנוגעות אליו. כל התשובות מתבססות על המידע שבטקסט בלבד.

### קטע הקריאה: The Tragedy of the Commons

> Imagine a shared pasture open to all the herders of a village. Each herder gains directly by adding one more animal to the land, since the profit from that animal is entirely his own. The cost of overgrazing, however, is shared by everyone. Because the individual benefit is concentrated while the harm is spread thin, every herder has an incentive to add more animals, even though the combined effect ruins the pasture for all. This pattern, often called the tragedy of the commons, appears wherever a valuable resource is shared but unregulated, from fisheries to clean air. The example is not an argument against cooperation but a warning about how rational individual choices can lead to a collectively poor outcome. Solutions usually involve agreed rules, shared responsibility, or limits on use, which align private incentives with the long-term health of the resource.

#### 13.

What does the "tragedy of the commons" describe?

**A.** How cooperation always destroys resources.  
**B.** Why herders should own private pastures only.  
**C.** How rational individual choices can ruin a shared resource.  
**D.** Why animals naturally avoid shared land.

#### 14.

Why does each herder gain by adding one more animal?

**A.** The cost of the animal is paid by the village.  
**B.** Adding animals improves the pasture.  
**C.** The other herders reward him for it.  
**D.** The profit from that animal is entirely his own.

#### 15.

How is the cost of overgrazing distributed?

**A.** It is shared by everyone.  
**B.** It is paid only by the richest herder.  
**C.** It falls entirely on one animal.  
**D.** It disappears completely.

#### 16.

Why does every herder have an incentive to add more animals?

**A.** The individual benefit is concentrated while the harm is spread thin.  
**B.** The harm is concentrated on one herder.  
**C.** There is no benefit to adding animals.  
**D.** The pasture grows larger with more animals.

#### 17.

According to the passage, the example serves as:

**A.** an argument against all forms of cooperation.  
**B.** proof that shared resources are always best.  
**C.** a reason to add as many animals as possible.  
**D.** a warning about how individual choices can harm everyone.

## פרק 4 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 18.

The two studies, while different in scope, reached similar conclusions.

**A.** Although the studies differed in how broad they were, they came to alike conclusions.  
**B.** The two studies were identical and reached the same conclusions.  
**C.** The two studies were similar in scope but reached opposite conclusions.  
**D.** The two studies shared the same scope yet disagreed entirely.

#### 19.

The law aims to deter companies from polluting rivers.

**A.** The law encourages companies to pollute rivers.  
**B.** The law allows companies to pollute rivers freely.  
**C.** The law is meant to discourage companies from polluting rivers.  
**D.** The law forces companies to clean already polluted rivers.

#### 20.

Seldom has a single invention transformed daily life so profoundly.

**A.** Many inventions have changed daily life just as deeply.  
**B.** Rarely has one invention changed everyday life so deeply.  
**C.** No invention has ever changed daily life at all.  
**D.** This invention changed daily life only in a minor way.

## פרק 5 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 21.

The decline in sales prompted the company to rethink its strategy.

**A.** Rising sales caused the company to change its strategy.  
**B.** The company changed its strategy, which lowered its sales.  
**C.** The company kept the same strategy despite falling sales.  
**D.** Falling sales led the company to reconsider its strategy.

#### 22.

The artist is admired not so much for skill as for originality.

**A.** People admire the artist for being original more than for being skillful.  
**B.** People admire the artist mainly for skill, not originality.  
**C.** The artist is admired equally for skill and originality.  
**D.** The artist is admired for neither skill nor originality.

#### 23.

The treaty will remain in force unless one side withdraws.

**A.** The treaty ends immediately even if both sides stay.  
**B.** The treaty stays valid only if one side withdraws.  
**C.** The treaty is already invalid because a side withdrew.  
**D.** The treaty stays valid until one of the sides pulls out.

## פרק 6 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 24.

The new employee adapted \_\_\_\_ to the company culture.

**A.** quietly  
**B.** quickly  
**C.** quite  
**D.** quiet

#### 25.

The bridge is closed \_\_\_\_ repairs are being made.

**A.** unless  
**B.** while  
**C.** whereas  
**D.** in case

#### 26.

The lecture was \_\_\_\_, covering only the surface of a complex subject.

**A.** exhaustive  
**B.** meticulous  
**C.** cursory  
**D.** rigorous

#### 27.

The painting is valued not for its size but for its \_\_\_\_ detail.

**A.** enormous  
**B.** obvious  
**C.** plain  
**D.** intricate

#### 28.

The historian sought to \_\_\_\_ myth from documented fact.

**A.** intertwine  
**B.** disentangle  
**C.** conflate  
**D.** merge

#### 29.

The argument \_\_\_\_ on a subtle but crucial distinction.

**A.** hinders  
**B.** hovers  
**C.** hampers  
**D.** hinges

---

## מפתח תשובות

| שאלה | תשובה | הניסוח הנכון |
|---|---|---|
| 1 | D | so as to |
| 2 | A | despite |
| 3 | A | rapidly |
| 4 | D | combines |
| 5 | A | rigorous |
| 6 | C | sweeping |
| 7 | B | analyzed |
| 8 | A | educate |
| 9 | C | common |
| 10 | A | inconsistent |
| 11 | C | circumstantial |
| 12 | B | if |
| 13 | C | How rational individual choices can ruin a shared resource. |
| 14 | D | The profit from that animal is entirely his own. |
| 15 | A | It is shared by everyone. |
| 16 | A | The individual benefit is concentrated while the harm is spread thin. |
| 17 | D | a warning about how individual choices can harm everyone. |
| 18 | A | Although the studies differed in how broad they were, they came to alike conclusions. |
| 19 | C | The law is meant to discourage companies from polluting rivers. |
| 20 | B | Rarely has one invention changed everyday life so deeply. |
| 21 | D | Falling sales led the company to reconsider its strategy. |
| 22 | A | People admire the artist for being original more than for being skillful. |
| 23 | D | The treaty stays valid until one of the sides pulls out. |
| 24 | B | quickly |
| 25 | B | while |
| 26 | C | cursory |
| 27 | D | intricate |
| 28 | B | disentangle |
| 29 | D | hinges |

## הסברים

**1.** So as to = כדי ל. החנות נשארת פתוחה כדי לשרת יותר לקוחות.

**2.** Despite = למרות. ניגוד בין הפופולריות להתנגדויות.

**3.** Rapidly = במהירות. התפשטות לפני הופעת תסמינים מצביעה על מהירות.

**4.** Combine = לשלב. הגישה החדשה משלבת את היתרונות של שתי השיטות.

**5.** Rigorous = קפדני. שימוש קפדני בשיטות סטטיסטיות.

**6.** Sweeping = מקיף/גורף. פירוק מבנים בני מאה שנה מצביע על רפורמה גורפת.

**7.** Analyze = לנתח. המדען ניתח את הנתונים לפני הסקת מסקנות.

**8.** Educate = לחנך/להקנות ידע. המאמר נועד להקנות ידע על תזונה.

**9.** Common ground = בסיס משותף. לאחר דיונים מצאו בסיס משותף.

**10.** Inconsistent with = לא עולה בקנה אחד. פער בין התנהגות לערכים מעורר חשד.

**11.** Circumstantial = נסיבתי. "at best ... not decisive" מתאים לראיה נסיבתית.

**12.** "provocative if not convincing": if כאן = "אם כי לא". מבנה ניגודי מתקדם.

**13.** הקטע מסביר כיצד בחירות פרטיות רציונליות יכולות להרוס משאב משותף.

**14.** נכתב: "the profit from that animal is entirely his own".

**15.** נכתב: "The cost of overgrazing, however, is shared by everyone".

**16.** נכתב: "Because the individual benefit is concentrated while the harm is spread thin, every herder has an incentive to add more animals".

**17.** נכתב: "a warning about how rational individual choices can lead to a collectively poor outcome".

**18.** "while different in scope ... similar conclusions" = שונים בהיקף אך מגיעים למסקנות דומות. התשובה הנכונה שומרת על שני הרכיבים.

**19.** Deter = להרתיע. התשובה הנכונה שומרת על "discourage companies from polluting rivers".

**20.** "Seldom has ... transformed ... so profoundly" = לעיתים נדירות שינתה המצאה כה עמוקות. התשובה הנכונה שומרת על "rarely ... changed everyday life so deeply".

**21.** Prompt = להניע; decline = ירידה. התשובה הנכונה שומרת על "falling sales led the company to reconsider its strategy".

**22.** "not so much for skill as for originality" = פחות בזכות המיומנות ויותר בזכות המקוריות. התשובה הנכונה שומרת על סדר העדיפות הזה.

**23.** "remain in force unless one side withdraws" = יישאר בתוקף אלא אם צד יפרוש. התשובה הנכונה שומרת על "stays valid until one of the sides pulls out".

**24.** Quickly = במהירות. העובד החדש הסתגל במהירות לתרבות החברה.

**25.** While = בזמן ש. הגשר סגור בזמן שמתבצעים תיקונים.

**26.** Cursory = שטחי/חטוף. "only the surface" מתאר סקירה חטופה.

**27.** Intricate = מורכב/עדין. "not for its size but" מצביע על פירוט מורכב.

**28.** Disentangle = להפריד/לפענח. ההיסטוריון ביקש להפריד מיתוס מעובדה.

**29.** Hinge on = להיות תלוי ב. הטיעון כולו תלוי בהבחנה דקה אך מכרעת.
