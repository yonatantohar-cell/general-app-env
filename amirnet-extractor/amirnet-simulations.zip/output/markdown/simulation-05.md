# סימולציה 5 — קל עד בינוני

סימולציה בשישה פרקי הליבה של האמירנט — השלמת משפטים, הבנת הנקרא וניסוח מחדש — ברמה קלה עד בינונית, מתאימה לתחילת התרגול.

**רמה:** קל  
**שאלות במאגר:** 29  
**מוגשות בסימולציה:** 23  
**זמן:** 39 דקות  
**מקור:** https://amirnetwords.com/tests/test-05/play

> הסימולציה מגישה 23 שאלות מתוך מאגר של 29, ובוחרת אותן באופן מסתגל. כאן מופיע המאגר המלא.

---

## פרק 1 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 1.

He was hungry, \_\_\_\_ he made himself a sandwich.

**A.** so  
**B.** but  
**C.** although  
**D.** because

#### 2.

A dictionary can \_\_\_\_ the meaning of new words.

**A.** erase  
**B.** enjoy  
**C.** enter  
**D.** explain

#### 3.

We were thirsty, \_\_\_\_ we bought some cold water.

**A.** but  
**B.** so  
**C.** although  
**D.** because

#### 4.

The runners were tired but \_\_\_\_ to finish the race.

**A.** delayed  
**B.** damaged  
**C.** determined  
**D.** doubtful

#### 5.

The teacher gave a clear \_\_\_\_ of the difficult concept.

**A.** exploration  
**B.** explanation  
**C.** expectation  
**D.** exception

#### 6.

The factory reduced waste \_\_\_\_ improving its profits.

**A.** while  
**B.** unless  
**C.** because  
**D.** since

## פרק 2 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 7.

The teacher will \_\_\_\_ the homework tomorrow morning.

**A.** climb  
**B.** cough  
**C.** collect  
**D.** crash

#### 8.

She smiled \_\_\_\_ she received the good news.

**A.** so  
**B.** but  
**C.** unless  
**D.** when

#### 9.

The bird built a \_\_\_\_ in the tall tree.

**A.** nest  
**B.** nail  
**C.** net  
**D.** note

#### 10.

Turn left at the corner \_\_\_\_ you will see the bank.

**A.** but  
**B.** because  
**C.** and  
**D.** although

#### 11.

We will go hiking tomorrow \_\_\_\_ the weather is good.

**A.** in spite of  
**B.** rather than  
**C.** provided that  
**D.** as well as

#### 12.

A reliable source is \_\_\_\_ when writing an academic paper.

**A.** crucial  
**B.** casual  
**C.** curious  
**D.** cruel

## פרק 3 — הבנת הנקרא

*5 שאלות בסימולציה · 5 במאגר · 15 דקות*

קראו את הקטע האקדמי הקצר ולאחר מכן ענו על השאלות הנוגעות אליו. כל התשובות מתבססות על המידע שבטקסט בלבד.

### קטע הקריאה: The Story of Chocolate

> Chocolate comes from the seeds of the cacao tree, which grows in warm places near the equator. Hundreds of years ago, people in Central America were the first to use these seeds. They did not eat sweet chocolate bars as we do today. Instead, they made a bitter drink by mixing ground cacao with water and spices. This drink was so valued that the seeds were sometimes used as money. When the drink later reached Europe, people there added sugar and milk to make it sweeter. Over time, factories learned to turn chocolate into the solid bars that are now sold around the world. Today, chocolate is one of the most popular treats on the planet, but few people know that it began as a bitter drink far from the candy shops of today.

#### 13.

What is the main topic of the passage?

**A.** The history of chocolate, from a bitter drink to modern bars.  
**B.** How to grow a cacao tree at home.  
**C.** Why people in Europe stopped eating chocolate.  
**D.** How factories build machines.

#### 14.

Where does chocolate come from?

**A.** The seeds of the cacao tree.  
**B.** The leaves of the sugar plant.  
**C.** The roots of a desert tree.  
**D.** The milk of certain animals.

#### 15.

How did people in Central America first use cacao seeds?

**A.** They ate sweet chocolate bars.  
**B.** They burned them for heat.  
**C.** They planted them in cold places.  
**D.** They made a bitter drink with water and spices.

#### 16.

According to the passage, the cacao seeds were so valued that they:

**A.** were given only to children.  
**B.** were never allowed to be sold.  
**C.** were thrown away after use.  
**D.** were sometimes used as money.

#### 17.

What did people in Europe add to the chocolate drink?

**A.** Sugar and milk.  
**B.** Water and spices.  
**C.** Salt and pepper.  
**D.** Fruit and nuts only.

## פרק 4 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 18.

The children were too tired to keep playing.

**A.** The children stopped playing because they were so tired.  
**B.** The children kept playing even though they were tired.  
**C.** The children were full of energy and played all night.  
**D.** The children were too excited to stop playing.

#### 19.

My neighbor often helps me carry the heavy bags.

**A.** My neighbor never helps me with the heavy bags.  
**B.** My neighbor frequently gives me a hand with the heavy bags.  
**C.** I usually help my neighbor carry the heavy bags.  
**D.** The bags are light, so I do not need any help.

#### 20.

The river is too deep for the children to swim safely.

**A.** The river is shallow enough for the children to swim safely.  
**B.** The children swim safely in the deep river every day.  
**C.** The children cannot swim safely because the river is so deep.  
**D.** The river is deep, but it is perfectly safe for children.

## פרק 5 — ניסוח מחדש

*3 שאלות בסימולציה · 3 במאגר · 6 דקות*

בכל שאלה מופיע משפט מקור באנגלית. בחרו מתוך ארבע אפשרויות את המשפט הקרוב ביותר במשמעותו למשפט המקורי, גם אם הניסוח שונה.

#### 21.

After the rain stopped, the sun came out again.

**A.** The sun came out before the rain started.  
**B.** The rain continued, so the sun never appeared.  
**C.** Once the rain had ended, the sun appeared once more.  
**D.** The sun disappeared right after the rain stopped.

#### 22.

The library is open to everyone who has a membership card.

**A.** The library is closed to people with a membership card.  
**B.** Only the staff can use the library, not members.  
**C.** Anyone holding a membership card may use the library.  
**D.** You can use the library without any membership card.

#### 23.

She always checks her work before she hands it in.

**A.** Before submitting her work, she never forgets to review it.  
**B.** She hands in her work without ever checking it.  
**C.** She checks her work only after handing it in.  
**D.** She rarely reviews her work before submitting it.

## פרק 6 — השלמת משפטים

*4 שאלות בסימולציה · 6 במאגר · 4 דקות*

בכל שאלה מופיע משפט באנגלית עם מילה חסרה. בחרו מתוך ארבע אפשרויות את המילה או הביטוי שמשלימים את המשפט בצורה הטובה ביותר, לפי אוצר המילים, הדקדוק ורמזי ההקשר.

#### 24.

We stayed inside \_\_\_\_ the weather was stormy.

**A.** because  
**B.** so  
**C.** but  
**D.** and

#### 25.

The store will \_\_\_\_ the broken phone for free.

**A.** remove  
**B.** reject  
**C.** return  
**D.** repair

#### 26.

He apologized \_\_\_\_ he had made a mistake.

**A.** because  
**B.** so  
**C.** but  
**D.** although

#### 27.

The road was icy; \_\_\_\_, the driver slowed down.

**A.** on the contrary  
**B.** for example  
**C.** in addition  
**D.** as a result

#### 28.

The novel offers a \_\_\_\_ description of life in the past.

**A.** vague  
**B.** violent  
**C.** vacant  
**D.** vivid

#### 29.

The two cities are similar \_\_\_\_ size but differ in culture.

**A.** in case of  
**B.** in favor of  
**C.** in terms of  
**D.** in charge of

---

## מפתח תשובות

| שאלה | תשובה | הניסוח הנכון |
|---|---|---|
| 1 | A | so |
| 2 | D | explain |
| 3 | B | so |
| 4 | C | determined |
| 5 | B | explanation |
| 6 | A | while |
| 7 | C | collect |
| 8 | D | when |
| 9 | A | nest |
| 10 | C | and |
| 11 | C | provided that |
| 12 | A | crucial |
| 13 | A | The history of chocolate, from a bitter drink to modern bars. |
| 14 | A | The seeds of the cacao tree. |
| 15 | D | They made a bitter drink with water and spices. |
| 16 | D | were sometimes used as money. |
| 17 | A | Sugar and milk. |
| 18 | A | The children stopped playing because they were so tired. |
| 19 | B | My neighbor frequently gives me a hand with the heavy bags. |
| 20 | C | The children cannot swim safely because the river is so deep. |
| 21 | C | Once the rain had ended, the sun appeared once more. |
| 22 | C | Anyone holding a membership card may use the library. |
| 23 | A | Before submitting her work, she never forgets to review it. |
| 24 | A | because |
| 25 | D | repair |
| 26 | A | because |
| 27 | D | as a result |
| 28 | D | vivid |
| 29 | C | in terms of |

## הסברים

**1.** הרעב הוא הסיבה; הכנת הכריך היא התוצאה: so.

**2.** Explain = להסביר. מילון מסביר את משמעות המילים.

**3.** הצמא הוא הסיבה; קניית המים היא התוצאה: so.

**4.** Determined = נחושים. למרות העייפות הם נחושים לסיים. הניגוד מסומן ב-but.

**5.** Explanation = הסבר. המורה נתן הסבר ברור למושג הקשה.

**6.** While כאן = בעוד/ובמקביל. המפעל הפחית פסולת ובו בזמן שיפר רווחים.

**7.** Collect = לאסוף. מורה אוסף שיעורי בית.

**8.** When מציין את הזמן: היא חייכה כאשר קיבלה את הבשורה.

**9.** ציפור בונה "קן" (nest) בעץ. שאר המילים אינן מתאימות.

**10.** And מחבר שתי פעולות עוקבות: פנה ואז תראה את הבנק.

**11.** Provided that = בתנאי ש. נצא לטיול בתנאי שמזג האוויר יהיה טוב.

**12.** Crucial = מכריע/קריטי. מקור מהימן חיוני בכתיבה אקדמית.

**13.** הקטע מספר את ההיסטוריה של השוקולד, ממשקה מר ועד החטיפים של היום.

**14.** נכתב: "Chocolate comes from the seeds of the cacao tree".

**15.** נכתב: "they made a bitter drink by mixing ground cacao with water and spices".

**16.** נכתב: "the seeds were sometimes used as money".

**17.** נכתב: "people there added sugar and milk to make it sweeter".

**18.** "too tired to keep playing" = עייפים מכדי להמשיך. התשובה הנכונה שומרת על "stopped playing because they were so tired".

**19.** "often helps" = עוזר לעיתים קרובות. התשובה הנכונה שומרת על "frequently gives me a hand".

**20.** "too deep ... to swim safely" = עמוק מכדי לשחות בבטחה. התשובה הנכונה שומרת על "cannot swim safely because the river is so deep".

**21.** "After the rain stopped" קובע סדר: קודם נגמר הגשם ואז יצאה השמש. התשובה הנכונה שומרת על הסדר.

**22.** התשובה הנכונה שומרת על "anyone holding a membership card may use the library".

**23.** "always checks ... before she hands it in" = תמיד בודקת לפני ההגשה. התשובה הנכונה שומרת על "before submitting ... never forgets to review".

**24.** מזג האוויר הסוער הוא הסיבה להישאר בפנים: because.

**25.** Repair = לתקן. תיקון מתאים ל"broken phone".

**26.** הטעות היא הסיבה להתנצלות: because.

**27.** As a result = כתוצאה מכך. הקרח גרם להאטת הנהיגה.

**28.** Vivid = חי/ציורי. הספר מציע תיאור חי של העבר.

**29.** In terms of = מבחינת. הערים דומות מבחינת גודל אך שונות בתרבות.
